/** @type {import('next').NextConfig} */
const nextConfig = {
    images: {
        remotePatterns: [
            { protocol: "https", hostname: "images.unsplash.com" },
            { protocol: "https", hostname: "*.supabase.co" },
        ],
    },
    // Ensure Stripe webhook can receive raw body
    experimental: {
        serverComponentsExternalPackages: ["@prisma/client"],
    },
};

module.exports = nextConfig;
