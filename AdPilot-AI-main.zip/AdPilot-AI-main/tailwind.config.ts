import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: "class",
  content: [
    "./pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      fontFamily: {
        sans: ["Inter", "system-ui", "sans-serif"],
      },
      colors: {
        dark: {
          DEFAULT: "#0a0a0f",
          50: "#f5f5fa",
          100: "#e8e8f5",
          200: "#c8c8e8",
          800: "#1a1a26",
          900: "#11111a",
          950: "#0a0a0f",
        },
        surface: {
          DEFAULT: "#111118",
          2: "#181824",
          3: "#1e1e2e",
        },
        "accent-violet": "#8b5cf6",
        "accent-indigo": "#6366f1",
        "accent-cyan": "#22d3ee",
      },
      backgroundImage: {
        "gradient-radial": "radial-gradient(var(--tw-gradient-stops))",
        "gradient-conic": "conic-gradient(from 180deg at 50% 50%, var(--tw-gradient-stops))",
        "glass-gradient": "linear-gradient(135deg, rgba(255,255,255,0.06), rgba(255,255,255,0.02))",
      },
      boxShadow: {
        "glass": "0 4px 24px rgba(0,0,0,0.4), inset 0 1px 0 rgba(255,255,255,0.06)",
        "glass-lg": "0 8px 48px rgba(0,0,0,0.5), inset 0 1px 0 rgba(255,255,255,0.08)",
        "glow-violet": "0 0 20px rgba(139,92,246,0.35), 0 0 60px rgba(139,92,246,0.1)",
        "glow-cyan": "0 0 20px rgba(34,211,238,0.3), 0 0 60px rgba(34,211,238,0.08)",
        "card": "0 1px 0 rgba(255,255,255,0.05), 0 16px 48px rgba(0,0,0,0.4)",
      },
      animation: {
        shimmer: "shimmer 2s ease-in-out infinite",
        float: "float 5s ease-in-out infinite",
        marquee: "marquee 30s linear infinite",
      },
      keyframes: {
        shimmer: {
          "0%,100%": { backgroundPosition: "-400% 0" },
          "50%": { backgroundPosition: "400% 0" },
        },
        float: {
          "0%,100%": { transform: "translateY(0)" },
          "50%": { transform: "translateY(-12px)" },
        },
        marquee: {
          from: { transform: "translateX(0)" },
          to: { transform: "translateX(-50%)" },
        },
      },
    },
  },
  plugins: [],
};

export default config;
