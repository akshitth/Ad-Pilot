/**
 * Supabase-backed database helper.
 * Exposes a Prisma-like API using the Supabase REST (PostgREST) client,
 * which uses the Service Role key — no DB password needed.
 */
import { supabaseAdmin } from "@/lib/supabase";

type VideoStatus = "PENDING" | "PROCESSING" | "COMPLETED" | "FAILED";
type Plan = "FREE" | "STARTER" | "PRO" | "BUSINESS";
type TransactionType = "PURCHASE" | "USAGE" | "REFUND" | "BONUS";

const db = {
  user: {
    findUnique: async ({ where }: { where: { clerkId?: string; id?: string; email?: string } }) => {
      let query = supabaseAdmin.from("User").select("*");
      if (where.clerkId) query = query.eq("clerkId", where.clerkId);
      if (where.id) query = query.eq("id", where.id);
      if (where.email) query = query.eq("email", where.email);
      const { data, error } = await query.single();
      if (error && error.code !== "PGRST116") throw error;
      return data || null;
    },
    create: async ({ data }: { data: any }) => {
      const { data: row, error } = await supabaseAdmin
        .from("User")
        .insert({ ...data, id: data.id || crypto.randomUUID(), updatedAt: new Date().toISOString() })
        .select()
        .single();
      if (error) throw error;
      return row;
    },
    update: async ({ where, data }: { where: { id?: string; clerkId?: string }; data: any }) => {
      let query = supabaseAdmin.from("User").update({ ...data, updatedAt: new Date().toISOString() });
      if (where.id) query = query.eq("id", where.id);
      if (where.clerkId) query = query.eq("clerkId", where.clerkId);
      const { data: row, error } = await query.select().single();
      if (error) throw error;
      return row;
    },
    count: async () => {
      const { count, error } = await supabaseAdmin.from("User").select("*", { count: "exact", head: true });
      if (error) throw error;
      return count ?? 0;
    },
  },

  video: {
    findUnique: async ({ where }: { where: { id: string } }) => {
      const { data, error } = await supabaseAdmin.from("Video").select("*").eq("id", where.id).single();
      if (error && error.code !== "PGRST116") throw error;
      return data || null;
    },
    findMany: async ({ where, orderBy }: { where?: any; orderBy?: any } = {}) => {
      let query = supabaseAdmin.from("Video").select("*");
      if (where?.userId) query = query.eq("userId", where.userId);
      if (orderBy?.createdAt === "desc") query = query.order("createdAt", { ascending: false });
      const { data, error } = await query;
      if (error) throw error;
      return data || [];
    },
    create: async ({ data }: { data: any }) => {
      const { data: row, error } = await supabaseAdmin
        .from("Video")
        .insert({ ...data, id: data.id || crypto.randomUUID(), updatedAt: new Date().toISOString() })
        .select()
        .single();
      if (error) throw error;
      return row;
    },
    update: async ({ where, data }: { where: { id: string }; data: any }) => {
      const { data: row, error } = await supabaseAdmin
        .from("Video")
        .update({ ...data, updatedAt: new Date().toISOString() })
        .eq("id", where.id)
        .select()
        .single();
      if (error) throw error;
      return row;
    },
    count: async () => {
      const { count, error } = await supabaseAdmin.from("Video").select("*", { count: "exact", head: true });
      if (error) throw error;
      return count ?? 0;
    },
  },

  creditTransaction: {
    create: async ({ data }: { data: any }) => {
      const { data: row, error } = await supabaseAdmin
        .from("CreditTransaction")
        .insert({ ...data, id: data.id || crypto.randomUUID() })
        .select()
        .single();
      if (error) throw error;
      return row;
    },
    findMany: async ({ where }: { where?: any } = {}) => {
      let query = supabaseAdmin.from("CreditTransaction").select("*");
      if (where?.userId) query = query.eq("userId", where.userId);
      const { data, error } = await query.order("createdAt", { ascending: false });
      if (error) throw error;
      return data || [];
    },
  },

  $disconnect: async () => { /* no-op with supabase */ },
};

export default db;
