import Stripe from "stripe";

// Lazy-initialize Stripe only on the server when needed (not at module load time)
let _stripe: Stripe | null = null;

export function getStripe(): Stripe {
    if (!_stripe) {
        if (!process.env.STRIPE_SECRET_KEY) {
            throw new Error("STRIPE_SECRET_KEY is not configured in environment variables.");
        }
        _stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
            apiVersion: "2026-01-28.clover",
            typescript: true,
        });
    }
    return _stripe;
}

// For backwards-compat with existing imports of `stripe`
export const stripe = new Proxy({} as Stripe, {
    get(_target, prop) {
        return (getStripe() as any)[prop];
    },
});

export const PLANS = {
    STARTER: {
        name: "Starter",
        price: 29,
        credits: 10,
        description: "Perfect for small businesses",
        features: [
            "10 AI Video generations",
            "20+ AI Actors",
            "HD video quality",
            "Email support",
        ],
        highlighted: false,
    },
    PRO: {
        name: "Pro",
        price: 79,
        credits: 35,
        description: "For growing marketing teams",
        features: [
            "35 AI Video generations",
            "50+ AI Actors",
            "4K video quality",
            "Priority support",
            "Custom backgrounds",
            "Script AI Assistant",
        ],
        highlighted: true,
    },
    BUSINESS: {
        name: "Business",
        price: 199,
        credits: 100,
        description: "Enterprise-grade for agencies",
        features: [
            "100 AI Video generations",
            "All AI Actors + Custom",
            "4K video quality",
            "Dedicated support",
            "API access",
            "White-labeling",
            "Team seats",
        ],
        highlighted: false,
    },
} as const;
