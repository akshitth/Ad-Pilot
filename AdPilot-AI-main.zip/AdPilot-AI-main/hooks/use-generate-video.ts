"use client";

import { useMutation, useQueryClient } from "@tanstack/react-query";

interface GenerateVideoParams {
    actorId: string;
    actorName: string;
    script: string;
    voiceTone: string;
}

interface GenerateVideoResult {
    jobId: string;
    videoUrl?: string;
    message: string;
}

async function generateVideoRequest(params: GenerateVideoParams): Promise<GenerateVideoResult> {
    const response = await fetch("/api/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(params),
    });

    // Guard against HTML error pages (server crash / DB not connected)
    const contentType = response.headers.get("content-type") || "";
    if (!contentType.includes("application/json")) {
        if (response.status === 500) {
            throw new Error("Server error: Database is not connected. Set your DATABASE_URL password in .env and run: npx prisma migrate dev --name init");
        }
        if (response.status === 401 || response.status === 403) {
            throw new Error("You must be signed in with sufficient credits.");
        }
        throw new Error(`Unexpected server error (${response.status}). Check your .env configuration.`);
    }

    const data = await response.json();
    if (!response.ok) {
        throw new Error(data.message || "Failed to generate video");
    }
    return data;
}

export function useGenerateVideo() {
    const queryClient = useQueryClient();

    return useMutation({
        mutationFn: generateVideoRequest,
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ["user-credits"] });
            queryClient.invalidateQueries({ queryKey: ["videos"] });
        },
    });
}
