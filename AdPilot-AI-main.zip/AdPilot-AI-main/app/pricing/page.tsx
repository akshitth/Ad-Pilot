import Link from "next/link";
import { Check, Zap, ArrowRight, Sparkles } from "lucide-react";
import { PLANS } from "@/lib/stripe";

// Re-export navbar component is "use client" so we build the nav inline here
import { Navbar } from "@/components/navbar";

const faqs = [
    { q: "Do credits expire?", a: "No — credits never expire. Use them at your own pace." },
    { q: "Can I get a refund?", a: "If a video fails to generate, you get a credit automatically refunded." },
    { q: "What payment methods?", a: "All major credit cards accepted securely via Stripe." },
    { q: "Is there an API?", a: "Business plan includes full API access for programmatic generation." },
];

export default function PricingPage() {
    return (
        <div className="min-h-screen" style={{ background: "rgb(10,10,15)" }}>
            <Navbar />
            <div className="pt-32 pb-24 px-6">
                <div className="max-w-5xl mx-auto">
                    {/* Header */}
                    <div className="text-center mb-16">
                        <div className="inline-flex items-center gap-2 glass px-4 py-2 rounded-full text-sm font-medium text-violet-400 border border-violet-500/20 mb-6">
                            <Zap className="w-4 h-4" />
                            Simple, credit-based pricing
                        </div>
                        <h1 className="text-5xl font-black text-white mb-4">
                            Pay only for what you{" "}
                            <span className="gradient-text">generate</span>
                        </h1>
                        <p className="text-white/40 text-xl max-w-xl mx-auto">
                            No subscriptions. No monthly fees. Buy credits when you need them.
                        </p>
                    </div>

                    {/* Free tier */}
                    <div className="glass-card rounded-2xl p-5 mb-6 flex flex-col sm:flex-row items-start sm:items-center gap-5">
                        <div className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0"
                            style={{ background: "linear-gradient(135deg, #8b5cf6, #6366f1)" }}>
                            <Sparkles className="w-5 h-5 text-white" />
                        </div>
                        <div>
                            <h3 className="text-base font-bold text-white">Free Forever</h3>
                            <p className="text-white/40 text-sm">3 free credits on sign up — no credit card required.</p>
                        </div>
                        <Link href="/sign-up"
                            className="sm:ml-auto shrink-0 inline-flex items-center gap-2 text-white text-sm font-bold px-5 py-2.5 rounded-xl"
                            style={{ background: "linear-gradient(135deg, #8b5cf6, #6366f1)" }}>
                            <Sparkles className="w-4 h-4" /> Start Free <ArrowRight className="w-4 h-4" />
                        </Link>
                    </div>

                    {/* Plans */}
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
                        {Object.entries(PLANS).map(([key, plan]) => (
                            <div key={key} className="rounded-2xl p-7 flex flex-col relative overflow-hidden"
                                style={{
                                    background: plan.highlighted ? "rgba(139,92,246,0.08)" : "rgba(255,255,255,0.03)",
                                    border: plan.highlighted ? "1px solid rgba(139,92,246,0.25)" : "1px solid rgba(255,255,255,0.07)",
                                    boxShadow: plan.highlighted ? "0 12px 48px rgba(139,92,246,0.25)" : "none",
                                }}>
                                <div className="absolute top-0 left-0 right-0 h-px"
                                    style={{ background: plan.highlighted ? "linear-gradient(90deg, transparent, rgba(139,92,246,0.7), transparent)" : "transparent" }} />
                                {plan.highlighted && (
                                    <span className="text-xs font-bold text-violet-300 self-start rounded-full px-3 py-1 mb-4"
                                        style={{ background: "rgba(139,92,246,0.15)", border: "1px solid rgba(139,92,246,0.25)" }}>
                                        ⭐ Most Popular
                                    </span>
                                )}
                                <h3 className="text-2xl font-black text-white">{plan.name}</h3>
                                <p className="text-white/35 text-sm mb-5">{plan.description}</p>
                                <div className="mb-3">
                                    <span className="text-5xl font-black text-white">${plan.price}</span>
                                    <span className="text-white/30 ml-2 text-sm">one-time</span>
                                </div>
                                <p className="text-violet-400 font-bold mb-5">{plan.credits} video credits</p>
                                <ul className="space-y-3 flex-1 mb-7">
                                    {plan.features.map((f) => (
                                        <li key={f} className="flex items-center gap-2.5 text-sm text-white/50">
                                            <div className="w-4.5 h-4.5 rounded-full flex items-center justify-center shrink-0"
                                                style={{ background: "rgba(52,211,153,0.12)" }}>
                                                <Check className="w-3 h-3 text-emerald-400" />
                                            </div>
                                            {f}
                                        </li>
                                    ))}
                                </ul>
                                <Link href="/sign-up"
                                    className="w-full text-center py-3.5 rounded-xl text-sm font-bold text-white transition-all hover:opacity-90"
                                    style={plan.highlighted ? {
                                        background: "linear-gradient(135deg, #8b5cf6, #6366f1)",
                                        boxShadow: "0 4px 16px rgba(139,92,246,0.4)"
                                    } : {
                                        background: "rgba(255,255,255,0.06)",
                                        border: "1px solid rgba(255,255,255,0.10)"
                                    }}>
                                    Get {plan.name} Pack
                                </Link>
                            </div>
                        ))}
                    </div>

                    {/* FAQ */}
                    <div className="mt-20 text-center">
                        <h2 className="text-2xl font-black text-white mb-2">FAQs</h2>
                        <p className="text-white/35 mb-10">Everything you need to know about pricing.</p>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-left">
                            {faqs.map((faq) => (
                                <div key={faq.q} className="glass-card rounded-xl p-5">
                                    <h4 className="text-sm font-bold text-white mb-2">{faq.q}</h4>
                                    <p className="text-sm text-white/40">{faq.a}</p>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}
