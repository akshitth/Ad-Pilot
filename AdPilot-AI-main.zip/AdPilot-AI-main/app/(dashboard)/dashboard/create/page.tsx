"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { ActorGrid } from "@/components/studio/actor-grid";
import { ScriptPanel } from "@/components/studio/script-panel";
import { VideoPreview } from "@/components/studio/video-preview";
import { useGenerateVideo } from "@/hooks/use-generate-video";
import type { Actor } from "@/lib/actors";
import { Sparkles, Users } from "lucide-react";

export default function CreatePage() {
    const [selectedActor, setSelectedActor] = useState<Actor | null>(null);
    const [script, setScript] = useState("");
    const [voiceTone, setVoiceTone] = useState("professional");

    const { mutate: generateVideo, isPending: isLoading, data: videoData, error } = useGenerateVideo();

    const handleGenerate = () => {
        if (!selectedActor || !script.trim()) return;
        generateVideo({ actorId: selectedActor.id, actorName: selectedActor.name, script, voiceTone });
    };

    return (
        <div className="h-full flex flex-col overflow-hidden">
            {/* Header bar */}
            <motion.div
                initial={{ opacity: 0, y: -12 }} animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
                className="px-7 py-4 flex items-center gap-3 shrink-0"
                style={{ borderBottom: "1px solid rgba(255,255,255,0.05)" }}
            >
                <div className="w-8 h-8 rounded-xl flex items-center justify-center"
                    style={{ background: "linear-gradient(135deg, #8b5cf6, #6366f1)" }}>
                    <Sparkles className="w-4 h-4 text-white" />
                </div>
                <div>
                    <h1 className="text-base font-black text-white leading-tight">Create Studio</h1>
                    <p className="text-[11px] text-white/30">Actor → Script → Generate</p>
                </div>
            </motion.div>

            <div className="flex-1 flex overflow-hidden">
                {/* Left — Actor Selection */}
                <div className="w-[45%] shrink-0 overflow-y-auto p-5"
                    style={{ borderRight: "1px solid rgba(255,255,255,0.05)" }}>
                    <div className="flex items-center gap-2 mb-4">
                        <Users className="w-3.5 h-3.5 text-cyan-400" />
                        <h2 className="text-[11px] font-bold text-white/30 uppercase tracking-widest">
                            Choose Actor
                        </h2>
                    </div>
                    <ActorGrid
                        selectedActorId={selectedActor?.id ?? null}
                        onSelect={setSelectedActor}
                    />
                </div>

                {/* Right — Script + Preview */}
                <div className="flex-1 flex flex-col overflow-y-auto">
                    {/* Script */}
                    <div className="p-5 border-b border-white/5">
                        <ScriptPanel
                            script={script}
                            onScriptChange={setScript}
                            voiceTone={voiceTone}
                            onVoiceToneChange={setVoiceTone}
                            selectedActor={selectedActor}
                            onGenerate={handleGenerate}
                            isLoading={isLoading}
                        />
                    </div>
                    {/* Preview */}
                    <div className="p-5">
                        <VideoPreview
                            isLoading={isLoading}
                            videoUrl={videoData?.videoUrl}
                            error={error as Error | null}
                            jobId={videoData?.jobId}
                        />
                    </div>
                </div>
            </div>
        </div>
    );
}
