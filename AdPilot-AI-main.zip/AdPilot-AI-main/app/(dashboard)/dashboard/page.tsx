"use client";

import { motion } from "framer-motion";
import Link from "next/link";
import { Film, PlusCircle, Zap, TrendingUp, Sparkles, ArrowRight, Clock, BarChart3 } from "lucide-react";
import { useQuery } from "@tanstack/react-query";

const stagger = { visible: { transition: { staggerChildren: 0.08 } } } as any;
const fadeUp = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.5, ease: [0.22, 1, 0.36, 1] } },
} as any;

const quickActions = [
    {
        href: "/dashboard/create",
        icon: PlusCircle,
        title: "Create New Video",
        desc: "Pick an actor, paste your script, generate in minutes.",
        color: "#8b5cf6",
        border: "rgba(139,92,246,0.2)",
    },
    {
        href: "/dashboard/library",
        icon: Film,
        title: "My Video Library",
        desc: "Browse, download, and share all your generated videos.",
        color: "#22d3ee",
        border: "rgba(34,211,238,0.2)",
    },
];

export default function DashboardHome() {
    const { data: userData } = useQuery({
        queryKey: ["user-credits"],
        queryFn: async () => { const r = await fetch("/api/user"); return r.json(); },
    });

    const statCards = [
        { label: "Videos Generated", value: userData?.videosGenerated ?? 0, icon: BarChart3, color: "#8b5cf6" },
        { label: "Credits Remaining", value: userData?.credits ?? 3, icon: Zap, color: "#fb923c" },
        { label: "Total Views", value: "—", icon: TrendingUp, color: "#34d399" },
    ];

    return (
        <div className="p-8 max-w-5xl">
            {/* Header */}
            <motion.div
                className="mb-10"
                initial={{ opacity: 0, y: -16 }} animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
            >
                <div className="flex items-center gap-2 mb-2">
                    <Sparkles className="w-4 h-4 text-violet-400" />
                    <p className="text-sm font-medium text-violet-400">Demo Arcade Studio</p>
                </div>
                <h1 className="text-4xl font-black text-white leading-tight">Dashboard</h1>
                <p className="text-white/35 mt-1.5">Welcome back. Ready to create your next ad?</p>
            </motion.div>

            {/* Stats */}
            <motion.div
                className="grid grid-cols-3 gap-4 mb-8"
                initial="hidden" animate="visible" variants={stagger}
            >
                {statCards.map((s) => (
                    <motion.div key={s.label} variants={fadeUp}
                        whileHover={{ y: -4, transition: { duration: 0.2 } }}
                        className="glass-card rounded-2xl p-5 relative overflow-hidden group cursor-default"
                        style={{ boxShadow: "0 1px 0 rgba(255,255,255,0.05), 0 16px 48px rgba(0,0,0,0.4)" }}
                    >
                        <div className="absolute top-0 left-0 right-0 h-px"
                            style={{ background: `linear-gradient(90deg, transparent, ${s.color}40, transparent)` }} />
                        <div className="flex items-start justify-between mb-3">
                            <p className="text-xs font-medium text-white/40">{s.label}</p>
                            <div className="w-8 h-8 rounded-lg flex items-center justify-center"
                                style={{ background: `${s.color}12`, border: `1px solid ${s.color}20` }}>
                                <s.icon className="w-4 h-4" style={{ color: s.color }} />
                            </div>
                        </div>
                        <p className="text-3xl font-black text-white">{s.value}</p>
                        <div className="h-0.5 w-8 rounded-full mt-4 opacity-60"
                            style={{ background: s.color }} />
                    </motion.div>
                ))}
            </motion.div>

            {/* Quick actions */}
            <motion.h2
                initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.3 }}
                className="text-sm font-bold text-white/40 uppercase tracking-widest mb-4"
            >
                Quick Actions
            </motion.h2>
            <motion.div
                className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8"
                initial="hidden" animate="visible" variants={{ visible: { transition: { staggerChildren: 0.1, delayChildren: 0.2 } } }}
            >
                {quickActions.map((a) => (
                    <motion.div key={a.href} variants={fadeUp}>
                        <Link href={a.href}>
                            <motion.div
                                whileHover={{ y: -4, transition: { duration: 0.2 } }}
                                className="glass-card rounded-2xl p-6 relative overflow-hidden group cursor-pointer"
                                style={{ border: `1px solid ${a.border}` }}
                            >
                                <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 rounded-2xl"
                                    style={{ background: `radial-gradient(circle at 30% 30%, ${a.color}08, transparent 70%)` }} />
                                <div className="relative z-10">
                                    <motion.div
                                        whileHover={{ scale: 1.1, rotate: 5 }}
                                        className="w-11 h-11 rounded-xl flex items-center justify-center mb-4"
                                        style={{ background: `${a.color}15`, border: `1px solid ${a.color}25` }}>
                                        <a.icon className="w-5 h-5" style={{ color: a.color }} />
                                    </motion.div>
                                    <h3 className="text-base font-semibold text-white mb-1.5">{a.title}</h3>
                                    <p className="text-sm text-white/40 leading-relaxed">{a.desc}</p>
                                    <div className="mt-4 flex items-center gap-1.5 text-xs font-medium"
                                        style={{ color: a.color }}>
                                        Get started
                                        <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                                    </div>
                                </div>
                            </motion.div>
                        </Link>
                    </motion.div>
                ))}
            </motion.div>

            {/* Tip */}
            <motion.div
                initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.45, duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
                className="rounded-2xl p-4 flex items-center gap-4"
                style={{
                    background: "rgba(139,92,246,0.06)",
                    border: "1px solid rgba(139,92,246,0.12)",
                }}
            >
                <div className="w-9 h-9 rounded-xl flex items-center justify-center shrink-0"
                    style={{ background: "linear-gradient(135deg, #8b5cf6, #6366f1)" }}>
                    <Clock className="w-4.5 h-4.5 text-white" />
                </div>
                <div className="flex-1">
                    <p className="text-sm font-semibold text-white/80">Videos generate in ~3 minutes</p>
                    <p className="text-xs text-white/35 mt-0.5">Our AI pipeline creates a fully lip-synced video and stores it in your library automatically.</p>
                </div>
                <Link href="/dashboard/create"
                    className="shrink-0 text-xs font-bold text-violet-400 hover:text-violet-300 transition-colors flex items-center gap-1">
                    Create <ArrowRight className="w-3.5 h-3.5" />
                </Link>
            </motion.div>
        </div>
    );
}
