import { auth } from "@clerk/nextjs/server";
import { redirect } from "next/navigation";
import { UserProfile } from "@clerk/nextjs";
import { Settings } from "lucide-react";

export default async function SettingsPage() {
    const { userId } = await auth();
    if (!userId) redirect("/sign-in");

    return (
        <div className="p-8 max-w-3xl">
            <div className="mb-8">
                <div className="flex items-center gap-2 mb-1">
                    <Settings className="w-4 h-4 text-slate-400" />
                    <p className="text-sm font-medium text-slate-400">Account</p>
                </div>
                <h1 className="text-4xl font-black text-white">Settings</h1>
                <p className="text-white/35 mt-1">Manage your profile and preferences.</p>
            </div>

            <UserProfile
                routing="hash"
                appearance={{
                    baseTheme: undefined,
                    variables: {
                        colorBackground: "#111118",
                        colorText: "#e8e8f5",
                        colorTextSecondary: "#7070a0",
                        colorInputBackground: "#1a1a26",
                        colorInputText: "#e8e8f5",
                        colorPrimary: "#8b5cf6",
                        colorNeutral: "#ffffff",
                        borderRadius: "12px",
                    },
                    elements: {
                        rootBox: "w-full",
                        card: "shadow-none border border-white/06 rounded-2xl",
                    },
                }}
            />
        </div>
    );
}
