"use client";

import { motion } from "framer-motion";
import { useQuery } from "@tanstack/react-query";
import { Film, Clock, CheckCircle, XCircle, Download, Loader2, PlusCircle, Sparkles } from "lucide-react";
import Link from "next/link";
import { formatRelativeTime } from "@/lib/utils";

interface Video {
    id: string; title: string; actorName: string;
    status: "PENDING" | "PROCESSING" | "COMPLETED" | "FAILED";
    videoUrl?: string; thumbnailUrl?: string; createdAt: string;
}

const statusConfig = {
    PENDING: { icon: Clock, color: "#fbbf24", bg: "rgba(251,191,36,0.1)", label: "Pending" },
    PROCESSING: { icon: Loader2, color: "#60a5fa", bg: "rgba(96,165,250,0.1)", label: "Processing", spin: true },
    COMPLETED: { icon: CheckCircle, color: "#34d399", bg: "rgba(52,211,153,0.1)", label: "Completed" },
    FAILED: { icon: XCircle, color: "#f87171", bg: "rgba(248,113,113,0.1)", label: "Failed" },
};

const fadeUp = {
    hidden: { opacity: 0, y: 16 },
    visible: (i: number) => ({ opacity: 1, y: 0, transition: { delay: i * 0.07, duration: 0.5, ease: [0.22, 1, 0.36, 1] } })
} as any;

export default function LibraryPage() {
    const { data, isLoading } = useQuery({
        queryKey: ["videos"],
        queryFn: async () => {
            const res = await fetch("/api/videos");
            if (!res.ok) throw new Error("Failed");
            return res.json() as Promise<{ videos: Video[] }>;
        },
        refetchInterval: 15000,
    });
    const videos = data?.videos || [];

    return (
        <div className="p-8 max-w-6xl">
            <motion.div initial={{ opacity: 0, y: -12 }} animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
                className="flex items-center justify-between mb-8">
                <div>
                    <div className="flex items-center gap-2 mb-1">
                        <Film className="w-4 h-4 text-emerald-400" />
                        <p className="text-sm font-medium text-emerald-400">Library</p>
                    </div>
                    <h1 className="text-4xl font-black text-white">My Library</h1>
                    <p className="text-white/35 mt-1">{videos.length} video{videos.length !== 1 ? "s" : ""} generated</p>
                </div>
                <motion.div whileHover={{ scale: 1.04 }} whileTap={{ scale: 0.97 }}>
                    <Link href="/dashboard/create"
                        className="flex items-center gap-2 text-white text-sm font-bold px-5 py-2.5 rounded-xl"
                        style={{ background: "linear-gradient(135deg, #8b5cf6, #6366f1)", boxShadow: "0 4px 16px rgba(139,92,246,0.35)" }}>
                        <PlusCircle className="w-4 h-4" /> Create New
                    </Link>
                </motion.div>
            </motion.div>

            {isLoading ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                    {[...Array(6)].map((_, i) => (
                        <div key={i} className="rounded-2xl h-56 shimmer" style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.06)" }} />
                    ))}
                </div>
            ) : videos.length === 0 ? (
                <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
                    className="flex flex-col items-center justify-center py-28 text-center">
                    <motion.div
                        animate={{ opacity: [0.3, 0.6, 0.3] }} transition={{ duration: 3, repeat: Infinity }}
                        className="w-20 h-20 rounded-3xl flex items-center justify-center mb-6"
                        style={{ background: "rgba(255,255,255,0.03)", border: "2px dashed rgba(255,255,255,0.08)" }}>
                        <Film className="w-9 h-9 text-white/20" />
                    </motion.div>
                    <h3 className="text-2xl font-black text-white mb-2">No videos yet</h3>
                    <p className="text-white/30 text-sm mb-8 max-w-xs">Generate your first AI video ad — takes under 3 minutes!</p>
                    <motion.div whileHover={{ scale: 1.04 }} whileTap={{ scale: 0.97 }}>
                        <Link href="/dashboard/create"
                            className="flex items-center gap-2 text-white font-bold px-8 py-3.5 rounded-xl"
                            style={{ background: "linear-gradient(135deg, #8b5cf6, #6366f1)", boxShadow: "0 8px 28px rgba(139,92,246,0.35)" }}>
                            <Sparkles className="w-4 h-4" /> Go to Studio →
                        </Link>
                    </motion.div>
                </motion.div>
            ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                    {videos.map((video, i) => {
                        const s = statusConfig[video.status];
                        return (
                            <motion.div key={video.id} custom={i} variants={fadeUp} initial="hidden" animate="visible"
                                whileHover={{ y: -5, transition: { duration: 0.2 } }}
                                className="rounded-2xl overflow-hidden group"
                                style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.07)", boxShadow: "0 4px 20px rgba(0,0,0,0.3)" }}>
                                <div className="aspect-video relative overflow-hidden"
                                    style={{ background: "rgba(255,255,255,0.02)" }}>
                                    {video.thumbnailUrl ? (
                                        <img src={video.thumbnailUrl} alt={video.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                                    ) : (
                                        <div className="w-full h-full flex items-center justify-center"
                                            style={{ background: "linear-gradient(135deg, rgba(139,92,246,0.06), rgba(99,102,241,0.04))" }}>
                                            {video.status === "PROCESSING"
                                                ? <Loader2 className="w-8 h-8 text-violet-400/40 animate-spin" />
                                                : <Film className="w-8 h-8 text-white/10" />}
                                        </div>
                                    )}
                                </div>
                                <div className="p-4">
                                    <p className="text-sm font-bold text-white truncate mb-0.5">{video.title}</p>
                                    <p className="text-xs text-white/30 mb-3">{video.actorName} · {formatRelativeTime(video.createdAt)}</p>
                                    <div className="flex items-center justify-between">
                                        <span className="inline-flex items-center gap-1.5 text-xs font-medium px-2.5 py-1 rounded-full"
                                            style={{ background: s.bg, color: s.color }}>
                                            <s.icon className={`w-3 h-3 ${(s as any).spin ? "animate-spin" : ""}`} />
                                            {s.label}
                                        </span>
                                        {video.videoUrl && (
                                            <a href={video.videoUrl} download
                                                className="flex items-center gap-1 text-xs font-medium text-violet-400 hover:text-violet-300 transition-colors">
                                                <Download className="w-3.5 h-3.5" />Download
                                            </a>
                                        )}
                                    </div>
                                </div>
                            </motion.div>
                        );
                    })}
                </div>
            )}
        </div>
    );
}
