"use client";

import { motion } from "framer-motion";
import Link from "next/link";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Zap, Check, Sparkles, ArrowRight, CreditCard, Clock } from "lucide-react";
import { PLANS } from "@/lib/stripe";
import { loadStripe } from "@stripe/stripe-js";

const stripePromise = loadStripe(process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY!);

const fadeUp = {
    hidden: { opacity: 0, y: 16 },
    visible: (i: number) => ({ opacity: 1, y: 0, transition: { delay: i * 0.1, duration: 0.5, ease: [0.22, 1, 0.36, 1] } }),
} as any;

export default function BillingPage() {
    const { data: userData, isLoading } = useQuery({
        queryKey: ["user-credits"],
        queryFn: async () => { const r = await fetch("/api/user"); return r.json(); },
    });

    const { mutate: checkout, isPending } = useMutation({
        mutationFn: async (priceId: string) => {
            const res = await fetch("/api/stripe/checkout", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ priceId }),
            });
            const data = await res.json();
            if (data.url) window.location.href = data.url;
        },
    });

    return (
        <div className="p-8 max-w-5xl">
            {/* Header */}
            <motion.div initial={{ opacity: 0, y: -12 }} animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }} className="mb-8">
                <div className="flex items-center gap-2 mb-1">
                    <CreditCard className="w-4 h-4 text-amber-400" />
                    <p className="text-sm font-medium text-amber-400">Billing</p>
                </div>
                <h1 className="text-4xl font-black text-white">Credits</h1>
                <p className="text-white/35 mt-1">Pay per video. No subscriptions.</p>
            </motion.div>

            {/* Balance banner */}
            <motion.div initial={{ opacity: 0, scale: 0.97 }} animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.1, duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
                className="rounded-2xl p-6 mb-8 relative overflow-hidden"
                style={{ background: "linear-gradient(135deg, #8b5cf6, #6366f1, #4338ca)", boxShadow: "0 12px 48px rgba(139,92,246,0.35)" }}>
                <div className="absolute top-0 left-0 right-0 h-px"
                    style={{ background: "linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent)" }} />
                <div className="absolute right-0 top-0 bottom-0 w-40 pointer-events-none"
                    style={{ background: "radial-gradient(circle at 100% 50%, rgba(255,255,255,0.1), transparent 70%)" }} />
                <div className="relative z-10 flex items-center gap-5">
                    <div className="w-14 h-14 rounded-2xl bg-white/15 flex items-center justify-center">
                        <Zap className="w-7 h-7 text-yellow-300" />
                    </div>
                    <div>
                        <p className="text-violet-200 text-sm font-medium mb-0.5">Current Balance</p>
                        <p className="text-5xl font-black text-white leading-none">
                            {isLoading ? "—" : userData?.credits ?? 0}
                            <span className="text-xl font-normal text-violet-300 ml-2">credits</span>
                        </p>
                        <p className="text-violet-300 text-xs mt-1.5">Plan: {userData?.plan || "FREE"}</p>
                    </div>
                </div>
            </motion.div>

            {/* Plans */}
            <motion.h2 initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.2 }}
                className="text-sm font-bold text-white/30 uppercase tracking-widest mb-5 flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-violet-400" /> Purchase Credits
            </motion.h2>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-10">
                {Object.entries(PLANS).map(([key, plan], i) => (
                    <motion.div key={key} custom={i} variants={fadeUp} initial="hidden" animate="visible"
                        whileHover={{ y: -4, transition: { duration: 0.2 } }}
                        className="rounded-2xl p-6 flex flex-col relative overflow-hidden"
                        style={{
                            background: plan.highlighted ? "rgba(139,92,246,0.08)" : "rgba(255,255,255,0.03)",
                            border: plan.highlighted ? "1px solid rgba(139,92,246,0.25)" : "1px solid rgba(255,255,255,0.07)",
                            boxShadow: plan.highlighted ? "0 8px 32px rgba(139,92,246,0.2)" : "none",
                        }}>
                        <div className="absolute top-0 left-0 right-0 h-px"
                            style={{ background: plan.highlighted ? "linear-gradient(90deg, transparent, rgba(139,92,246,0.6), transparent)" : "transparent" }} />
                        {plan.highlighted && (
                            <span className="text-xs font-bold text-violet-300 self-start rounded-full px-3 py-1 mb-4"
                                style={{ background: "rgba(139,92,246,0.15)", border: "1px solid rgba(139,92,246,0.25)" }}>
                                ⭐ Most Popular
                            </span>
                        )}
                        <h3 className="text-xl font-black text-white mb-1">{plan.name}</h3>
                        <p className="text-xs text-white/35 mb-4">{plan.description}</p>
                        <div className="mb-3">
                            <span className="text-4xl font-black text-white">${plan.price}</span>
                            <span className="text-white/30 ml-1.5 text-sm">one-time</span>
                        </div>
                        <p className="text-violet-400 font-bold text-sm mb-4">{plan.credits} credits</p>
                        <ul className="space-y-2.5 flex-1 mb-5">
                            {plan.features.map((f) => (
                                <li key={f} className="flex items-center gap-2.5 text-xs text-white/50">
                                    <div className="w-4 h-4 rounded-full flex items-center justify-center shrink-0"
                                        style={{ background: "rgba(52,211,153,0.12)" }}>
                                        <Check className="w-2.5 h-2.5 text-emerald-400" />
                                    </div>
                                    {f}
                                </li>
                            ))}
                        </ul>
                        <motion.button
                            whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}
                            onClick={() => (plan as any).priceId && checkout((plan as any).priceId)}
                            disabled={isPending || !(plan as any).priceId}
                            className="w-full py-3 rounded-xl text-sm font-bold text-white transition-all disabled:opacity-50"
                            style={plan.highlighted ? {
                                background: "linear-gradient(135deg, #8b5cf6, #6366f1)",
                                boxShadow: "0 4px 16px rgba(139,92,246,0.35)"
                            } : {
                                background: "rgba(255,255,255,0.06)",
                                border: "1px solid rgba(255,255,255,0.1)"
                            }}>
                            Get {plan.name}
                        </motion.button>
                    </motion.div>
                ))}
            </div>

            {/* Transactions */}
            <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4, duration: 0.5 }}>
                <h2 className="text-sm font-bold text-white/30 uppercase tracking-widest mb-4 flex items-center gap-2">
                    <Clock className="w-3.5 h-3.5" /> Transaction History
                </h2>
                <div className="rounded-2xl overflow-hidden"
                    style={{ background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.06)" }}>
                    <div className="p-8 text-center text-white/20 text-sm">
                        No transactions yet. Purchase credits to get started.
                    </div>
                </div>
            </motion.div>
        </div>
    );
}
