"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { motion, useScroll, useTransform, useInView, AnimatePresence } from "framer-motion";
import {
  Sparkles, Play, Zap, Globe, Clock, Star, Check,
  ArrowRight, Film, Mic, Wand2, Rocket, ChevronRight,
  Users, TrendingUp, Shield
} from "lucide-react";

/* ── Animation variants ── */
const fadeUp = {
  hidden: { opacity: 0, y: 30 },
  visible: (i = 0) => ({
    opacity: 1, y: 0,
    transition: { duration: 0.6, delay: i * 0.12, ease: [0.22, 1, 0.36, 1] }
  }),
} as any;
const stagger = {
  visible: { transition: { staggerChildren: 0.1 } },
} as any;

/* ── Data ── */
const features = [
  {
    icon: Film, label: "50+ AI Actors",
    desc: "Photorealistic avatars that lip-sync perfectly to any script.",
    color: "#8b5cf6",
  },
  {
    icon: Zap, label: "3-Min Delivery",
    desc: "Script to polished video — faster than a coffee break.",
    color: "#22d3ee",
  },
  {
    icon: Globe, label: "40+ Languages",
    desc: "Authentic accents and flawless pronunciation worldwide.",
    color: "#f472b6",
  },
  {
    icon: Wand2, label: "AI Scriptwriter",
    desc: "GPT-powered copy that converts. One product description → winning script.",
    color: "#a78bfa",
  },
  {
    icon: Mic, label: "ElevenLabs Voice",
    desc: "Ultra-realistic voices — emotional, professional, or casual tones.",
    color: "#34d399",
  },
  {
    icon: Shield, label: "Credits Never Expire",
    desc: "No subscriptions. Pay per video. Use them whenever.",
    color: "#fb923c",
  },
];

const steps = [
  { n: "01", title: "Pick Your Actor", desc: "Browse 50+ photorealistic AI avatars. Filter by tone, age, and style.", color: "#8b5cf6" },
  { n: "02", title: "Write or Generate", desc: "Paste your script or let GPT-4 write one from your product description.", color: "#22d3ee" },
  { n: "03", title: "Download & Ship", desc: "Get a 1080p lip-synced video ready for any platform in under 3 minutes.", color: "#f472b6" },
];

const brands = ["TechFlow", "Launchly", "Creatify", "AdMorph", "Studiomatic", "CorePlay", "Vidcraft", "SparkAds"];

const stats = [
  { value: "50+", label: "AI Actors" },
  { value: "<3m", label: "Render Time" },
  { value: "40+", label: "Languages" },
  { value: "10k+", label: "Videos Made" },
];

/* ── Floating glass card ── */
function FloatingCard({ className, style, children }: any) {
  return (
    <motion.div
      className={`glass-card rounded-2xl p-4 text-sm text-white/80 ${className}`}
      style={style}
      animate={{ y: [0, -8, 0] }}
      transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
    >
      {children}
    </motion.div>
  );
}

/* ── Feature card ── */
function FeatureCard({ icon: Icon, label, desc, color, i }: any) {
  return (
    <motion.div
      custom={i}
      variants={fadeUp}
      whileHover={{ y: -6, transition: { duration: 0.25 } }}
      className="glass-card rounded-2xl p-6 relative group overflow-hidden cursor-default"
    >
      {/* Glow on hover */}
      <motion.div
        className="absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500"
        style={{ background: `radial-gradient(circle at 50% 0%, ${color}18, transparent 70%)` }}
      />
      {/* Top border accent */}
      <div className="absolute top-0 left-0 right-0 h-px"
        style={{ background: `linear-gradient(90deg, transparent, ${color}60, transparent)` }} />

      <div className="relative z-10">
        <div className="w-11 h-11 rounded-xl flex items-center justify-center mb-4"
          style={{ background: `${color}14`, border: `1px solid ${color}30` }}>
          <Icon className="w-5 h-5" style={{ color }} />
        </div>
        <h3 className="text-base font-semibold text-white mb-2">{label}</h3>
        <p className="text-sm text-white/45 leading-relaxed">{desc}</p>
      </div>
    </motion.div>
  );
}

/* ── Step card ── */
function StepCard({ n, title, desc, color, i }: any) {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-80px" });
  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 40 }}
      animate={inView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.6, delay: i * 0.15, ease: [0.22, 1, 0.36, 1] }}
      className="glass-card rounded-2xl p-7 relative group"
    >
      <div className="absolute top-0 left-0 right-0 h-px"
        style={{ background: `linear-gradient(90deg, transparent, ${color}50, transparent)` }} />
      <span className="text-5xl font-black mb-4 block"
        style={{ color: `${color}20`, fontVariantNumeric: "tabular-nums" }}>
        {n}
      </span>
      <h3 className="text-lg font-semibold text-white mb-2">{title}</h3>
      <p className="text-sm text-white/45 leading-relaxed">{desc}</p>
      <div className="mt-5 flex items-center gap-2 text-xs font-medium"
        style={{ color }}>
        <div className="w-4 h-px" style={{ background: color }} />
        Step {parseInt(n)}
      </div>
    </motion.div>
  );
}

export default function LandingPage() {
  const heroRef = useRef(null);
  const { scrollYProgress } = useScroll({ target: heroRef, offset: ["start start", "end start"] });
  const y1 = useTransform(scrollYProgress, [0, 1], [0, 80]);
  const y2 = useTransform(scrollYProgress, [0, 1], [0, -50]);
  const opacity = useTransform(scrollYProgress, [0, 0.5], [1, 0]);

  const words = ["That Convert.", "In Minutes.", "At Scale.", "That Wow."];
  const [wordIndex, setWordIndex] = useState(0);
  useEffect(() => {
    const t = setInterval(() => setWordIndex(i => (i + 1) % words.length), 2800);
    return () => clearInterval(t);
  }, []);

  return (
    <div className="min-h-screen bg-dark-950 text-white overflow-x-hidden">
      {/* ── Navbar ── */}
      <NavbarInline />

      {/* ── Hero ────────────────────────────────── */}
      <section ref={heroRef} className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20">
        {/* Grid bg */}
        <div className="absolute inset-0 grid-bg opacity-100 pointer-events-none" />
        {/* Radial gradient vignette */}
        <div className="absolute inset-0 pointer-events-none"
          style={{ background: "radial-gradient(ellipse 80% 60% at 50% 0%, rgba(139,92,246,0.12), transparent)" }} />
        {/* Bottom fade */}
        <div className="absolute bottom-0 left-0 right-0 h-40 pointer-events-none"
          style={{ background: "linear-gradient(to bottom, transparent, rgb(10,10,15))" }} />

        {/* Floating purple orbs */}
        <motion.div
          className="absolute top-32 left-16 w-72 h-72 rounded-full pointer-events-none"
          animate={{ opacity: [0.12, 0.22, 0.12] }}
          transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
          style={{ background: "radial-gradient(circle, rgba(139,92,246,0.25), transparent 70%)", y: y1 }} />
        <motion.div
          className="absolute bottom-32 right-16 w-56 h-56 rounded-full pointer-events-none"
          animate={{ opacity: [0.08, 0.18, 0.08] }}
          transition={{ duration: 8, repeat: Infinity, ease: "easeInOut", delay: 2 }}
          style={{ background: "radial-gradient(circle, rgba(34,211,238,0.2), transparent 70%)", y: y2 }} />

        {/* Content */}
        <motion.div style={{ opacity }} className="relative z-10 max-w-5xl mx-auto px-6 text-center">
          {/* Badge */}
          <motion.div
            initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
            className="inline-flex items-center gap-2.5 glass px-4 py-2 rounded-full text-sm font-medium mb-8"
          >
            <span className="flex h-2 w-2 relative">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-violet-400 opacity-75" />
              <span className="relative inline-flex h-2 w-2 rounded-full bg-violet-500" />
            </span>
            <span className="text-white/60">Powered by</span>
            <span className="text-white font-semibold">HeyGen + ElevenLabs</span>
            <span className="text-white/30">·</span>
            <span className="text-violet-400">Beta</span>
          </motion.div>

          {/* Headline */}
          <motion.h1
            custom={1} variants={fadeUp} initial="hidden" animate="visible"
            className="text-6xl sm:text-7xl md:text-[82px] font-black tracking-tight leading-[1.03] mb-6"
          >
            <span className="block text-white">Create AI Video Ads</span>
            <span className="block gradient-text glow-text-violet">
              <AnimatePresence mode="wait">
                <motion.span key={wordIndex}
                  initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -16 }}
                  transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
                  className="block"
                >
                  {words[wordIndex]}
                </motion.span>
              </AnimatePresence>
            </span>
          </motion.h1>

          <motion.p
            custom={2} variants={fadeUp} initial="hidden" animate="visible"
            className="text-lg sm:text-xl text-white/45 max-w-2xl mx-auto mb-10 leading-relaxed"
          >
            Choose from 50+ photorealistic AI actors, paste your script, and render
            a professional lip-synced video in under 3 minutes. Zero cameras. Zero crew.
          </motion.p>

          {/* CTAs */}
          <motion.div
            custom={3} variants={fadeUp} initial="hidden" animate="visible"
            className="flex flex-col sm:flex-row items-center justify-center gap-4"
          >
            <MagneticButton href="/sign-up">
              <Sparkles className="w-5 h-5" />
              Generate Your First Ad Free
              <ArrowRight className="w-5 h-5" />
            </MagneticButton>
            <Link href="#how-it-works"
              className="flex items-center gap-2 text-white/50 hover:text-white/80 text-sm font-medium transition-colors group">
              <div className="w-8 h-8 rounded-full glass flex items-center justify-center group-hover:bg-white/10 transition-colors">
                <Play className="w-3.5 h-3.5" />
              </div>
              See how it works
            </Link>
          </motion.div>

          {/* Trust line */}
          <motion.div custom={4} variants={fadeUp} initial="hidden" animate="visible"
            className="mt-8 flex flex-wrap justify-center gap-5">
            {["No credit card", "3 free videos", "Cancel anytime"].map(t => (
              <span key={t} className="flex items-center gap-1.5 text-xs text-white/30">
                <Check className="w-3.5 h-3.5 text-violet-500" />{t}
              </span>
            ))}
          </motion.div>
        </motion.div>

        {/* Floating glass cards */}
        <FloatingCard
          className="absolute left-[6%] top-[30%] hidden xl:block w-52 shadow-glass"
          style={{ animationDelay: "0s" }}
        >
          <div className="flex items-center gap-2 mb-2">
            <div className="w-6 h-6 rounded-full bg-violet-500/20 flex items-center justify-center">
              <Zap className="w-3 h-3 text-violet-400" />
            </div>
            <span className="text-white/70 text-xs font-medium">Video Ready</span>
          </div>
          <p className="text-white font-semibold text-sm">Anna — Professional</p>
          <p className="text-white/40 text-xs mt-0.5">Generated in 2m 47s</p>
        </FloatingCard>

        <FloatingCard
          className="absolute right-[6%] top-[25%] hidden xl:block w-48 shadow-glass"
          style={{ animationDelay: "1.5s" }}
        >
          <div className="flex items-center gap-1.5 mb-1.5">
            <Star className="w-3.5 h-3.5 text-yellow-400" fill="currentColor" />
            <span className="text-white/60 text-xs">1080p HD</span>
          </div>
          <p className="text-white text-sm font-medium">40+ voices available</p>
          <div className="flex gap-1 mt-2">
            {["EN", "ES", "FR", "DE"].map(l => (
              <span key={l} className="text-[10px] glass px-1.5 py-0.5 rounded text-white/50">{l}</span>
            ))}
          </div>
        </FloatingCard>
      </section>

      {/* ── Stats ──────────────────────────────── */}
      <section className="py-16 px-6 border-y border-white/5">
        <motion.div
          className="max-w-4xl mx-auto grid grid-cols-2 sm:grid-cols-4 gap-8"
          initial="hidden" whileInView="visible" viewport={{ once: true, margin: "-80px" }}
          variants={stagger}
        >
          {stats.map(s => (
            <motion.div key={s.label} variants={fadeUp} className="text-center">
              <p className="text-4xl font-black gradient-text mb-1">{s.value}</p>
              <p className="text-sm text-white/35 font-medium">{s.label}</p>
            </motion.div>
          ))}
        </motion.div>
      </section>

      {/* ── Features ───────────────────────────── */}
      <section id="features" className="py-28 px-6">
        <div className="max-w-6xl mx-auto">
          <motion.div className="text-center mb-16"
            initial="hidden" whileInView="visible" viewport={{ once: true, margin: "-80px" }}
            variants={stagger}
          >
            <motion.p variants={fadeUp} className="text-sm font-semibold text-violet-400 uppercase tracking-widest mb-3">
              Why Demo Arcade
            </motion.p>
            <motion.h2 variants={fadeUp}
              className="text-4xl sm:text-5xl font-black text-white mb-4">
              Everything in one <span className="gradient-text">studio</span>
            </motion.h2>
            <motion.p variants={fadeUp} className="text-white/40 text-lg max-w-xl mx-auto">
              Professional AI video tools. Previously only available to agencies with massive budgets.
            </motion.p>
          </motion.div>

          <motion.div
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4"
            initial="hidden" whileInView="visible" viewport={{ once: true, margin: "-80px" }}
            variants={stagger}
          >
            {features.map((f, i) => <FeatureCard key={f.label} {...f} i={i} />)}
          </motion.div>
        </div>
      </section>

      {/* ── How It Works ───────────────────────── */}
      <section id="how-it-works" className="py-28 px-6 relative">
        <div className="absolute inset-0 pointer-events-none"
          style={{ background: "radial-gradient(ellipse 60% 40% at 50% 50%, rgba(139,92,246,0.06), transparent)" }} />
        <div className="max-w-5xl mx-auto relative">
          <div className="text-center mb-16">
            <p className="text-sm font-semibold text-cyan-400 uppercase tracking-widest mb-3">The Process</p>
            <h2 className="text-4xl sm:text-5xl font-black text-white">
              Ready in <span className="gradient-text">3 steps</span>
            </h2>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-5 relative">
            {/* Connector */}
            <div className="hidden sm:block absolute top-1/3 left-1/3 right-1/3 h-px"
              style={{ background: "linear-gradient(90deg, rgba(139,92,246,0.3), rgba(34,211,238,0.3))" }} />
            {steps.map((s, i) => <StepCard key={s.n} {...s} i={i} />)}
          </div>
        </div>
      </section>

      {/* ── Social Proof ───────────────────────── */}
      <section className="py-16 border-y border-white/5 overflow-hidden">
        <p className="text-center text-xs font-semibold text-white/20 uppercase tracking-widest mb-8">
          Trusted by teams at
        </p>
        <div className="flex">
          <div className="flex gap-16 animate-marquee shrink-0 items-center">
            {[...brands, ...brands].map((b, i) => (
              <span key={i} className="text-white/15 font-bold text-lg tracking-tight whitespace-nowrap">{b}</span>
            ))}
          </div>
        </div>
      </section>

      {/* ── CTA ────────────────────────────────── */}
      <section className="py-32 px-6">
        <motion.div
          initial={{ opacity: 0, y: 40 }} whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
          className="max-w-2xl mx-auto text-center"
        >
          <div className="glass-card rounded-3xl p-14 relative overflow-hidden">
            <div className="absolute inset-0 pointer-events-none"
              style={{ background: "radial-gradient(ellipse 80% 60% at 50% -10%, rgba(139,92,246,0.2), transparent)" }} />
            <div className="absolute top-0 left-0 right-0 h-px"
              style={{ background: "linear-gradient(90deg, transparent, rgba(139,92,246,0.6), rgba(34,211,238,0.4), transparent)" }} />
            <Rocket className="w-10 h-10 text-violet-400/60 mx-auto mb-6" />
            <h2 className="text-4xl sm:text-5xl font-black text-white mb-4">
              Start creating <span className="gradient-text">for free</span>
            </h2>
            <p className="text-white/40 text-lg mb-8">
              3 video credits. No credit card. No commitments.
            </p>
            <MagneticButton href="/sign-up" large>
              Get Started Free
              <ArrowRight className="w-5 h-5" />
            </MagneticButton>
          </div>
        </motion.div>
      </section>

      {/* ── Footer ─────────────────────────────── */}
      <footer className="border-t border-white/5 py-8 px-6">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-lg flex items-center justify-center"
              style={{ background: "linear-gradient(135deg, #8b5cf6, #6366f1)" }}>
              <Sparkles className="w-3.5 h-3.5 text-white" />
            </div>
            <span className="text-white/25 text-sm">© 2025 Demo Arcade. All rights reserved.</span>
          </div>
          <div className="flex gap-6 text-sm text-white/30">
            <Link href="/pricing" className="hover:text-white/60 transition-colors">Pricing</Link>
            <Link href="/sign-in" className="hover:text-white/60 transition-colors">Sign In</Link>
            <Link href="/sign-up" className="hover:text-white/60 transition-colors font-medium text-violet-400">Get Started →</Link>
          </div>
        </div>
      </footer>
    </div>
  );
}

/* ── Magnetic CTA Button ── */
function MagneticButton({ href, children, large = false }: { href: string; children: React.ReactNode; large?: boolean }) {
  const ref = useRef<HTMLAnchorElement>(null);
  const [pos, setPos] = useState({ x: 0, y: 0 });

  const handleMouseMove = (e: React.MouseEvent) => {
    const rect = ref.current?.getBoundingClientRect();
    if (!rect) return;
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;
    setPos({ x: (e.clientX - cx) * 0.2, y: (e.clientY - cy) * 0.2 });
  };
  const handleMouseLeave = () => setPos({ x: 0, y: 0 });

  return (
    <motion.a
      ref={ref}
      href={href}
      animate={{ x: pos.x, y: pos.y }}
      transition={{ type: "spring", stiffness: 300, damping: 20 }}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      whileHover={{ scale: 1.04 }}
      whileTap={{ scale: 0.97 }}
      className={`group relative inline-flex items-center gap-2.5 font-bold text-white rounded-xl overflow-hidden ${large ? "px-10 py-4.5 text-base" : "px-7 py-3.5 text-sm"}`}
      style={{ background: "linear-gradient(135deg, #8b5cf6, #6366f1, #22d3ee)", backgroundSize: "200% 200%" }}
    >
      <motion.div
        className="absolute inset-0"
        style={{ background: "linear-gradient(135deg, #a78bfa, #818cf8, #38bdf8)", backgroundSize: "200% 200%" }}
        initial={{ opacity: 0 }}
        whileHover={{ opacity: 1 }}
        transition={{ duration: 0.3 }}
      />
      {/* Glow */}
      <span className="absolute inset-0 blur-md opacity-0 group-hover:opacity-40 transition-opacity duration-300"
        style={{ background: "linear-gradient(135deg, #8b5cf6, #22d3ee)" }} />
      <span className="relative z-10 flex items-center gap-2.5">{children}</span>
    </motion.a>
  );
}

/* ── Inline Navbar (for landing only) ── */
function NavbarInline() {
  const [scrolled, setScrolled] = useState(false);
  useEffect(() => {
    const h = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", h, { passive: true });
    return () => window.removeEventListener("scroll", h);
  }, []);

  return (
    <motion.nav
      initial={{ y: -20, opacity: 0 }} animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${scrolled ? "glass border-b border-white/5 shadow-glass" : "bg-transparent"}`}
    >
      <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2.5 group">
          <motion.div
            whileHover={{ scale: 1.1, rotate: 5 }}
            className="w-8 h-8 rounded-xl flex items-center justify-center"
            style={{ background: "linear-gradient(135deg, #8b5cf6, #6366f1)" }}>
            <Sparkles className="w-4 h-4 text-white" />
          </motion.div>
          <span className="font-black text-lg text-white tracking-tight">
            Demo<span className="gradient-text">-Arcade</span>
          </span>
        </Link>

        <div className="hidden md:flex items-center gap-8">
          {[["Features", "/#features"], ["How it Works", "/#how-it-works"], ["Pricing", "/pricing"]].map(([label, href]) => (
            <NavLink key={label} href={href}>{label}</NavLink>
          ))}
        </div>

        <div className="flex items-center gap-3">
          <Link href="/sign-in" className="text-sm font-medium text-white/50 hover:text-white transition-colors px-3 py-2">
            Sign In
          </Link>
          <motion.div whileHover={{ scale: 1.04 }} whileTap={{ scale: 0.97 }}>
            <Link href="/sign-up"
              className="text-sm font-semibold text-white px-4 py-2 rounded-lg"
              style={{ background: "linear-gradient(135deg, #8b5cf6, #6366f1)" }}>
              Get Started
            </Link>
          </motion.div>
        </div>
      </div>
    </motion.nav>
  );
}

function NavLink({ href, children }: { href: string; children: React.ReactNode }) {
  return (
    <Link href={href} className="relative text-sm font-medium text-white/50 hover:text-white transition-colors group py-1">
      {children}
      <span className="absolute bottom-0 left-0 w-0 h-px bg-violet-400 group-hover:w-full transition-all duration-300" />
    </Link>
  );
}
