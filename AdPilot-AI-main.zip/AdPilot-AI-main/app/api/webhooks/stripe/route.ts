import { NextRequest, NextResponse } from "next/server";
import { stripe } from "@/lib/stripe";
import prisma from "@/lib/prisma";
import Stripe from "stripe";

export async function POST(req: NextRequest) {
    const body = await req.text();
    const signature = req.headers.get("stripe-signature");

    if (!signature) {
        return NextResponse.json({ message: "Missing signature" }, { status: 400 });
    }

    let event: Stripe.Event;
    try {
        event = stripe.webhooks.constructEvent(
            body,
            signature,
            process.env.STRIPE_WEBHOOK_SECRET!
        );
    } catch (err: any) {
        console.error("[Stripe Webhook] Signature verification failed:", err.message);
        return NextResponse.json({ message: `Webhook Error: ${err.message}` }, { status: 400 });
    }

    if (event.type === "checkout.session.completed") {
        const session = event.data.object as Stripe.Checkout.Session;

        const { userId, credits, planKey } = session.metadata || {};
        if (!userId || !credits) {
            console.error("[Stripe Webhook] Missing metadata");
            return NextResponse.json({ received: true });
        }

        const creditsToAdd = parseInt(credits, 10);

        try {
            // Map planKey to Plan enum
            const planMap: Record<string, "STARTER" | "PRO" | "BUSINESS"> = {
                STARTER: "STARTER",
                PRO: "PRO",
                BUSINESS: "BUSINESS",
            };
            const plan = planMap[planKey] || "STARTER";

            // Add credits to user and update plan
            await prisma.user.update({
                where: { id: userId },
                data: {
                    credits: { increment: creditsToAdd },
                    plan,
                },
            });

            // Record transaction
            await prisma.creditTransaction.create({
                data: {
                    userId,
                    amount: creditsToAdd,
                    type: "PURCHASE",
                    description: `Purchased ${plan} pack - ${creditsToAdd} credits`,
                    stripeSessionId: session.id,
                },
            });

            console.log(`[Stripe Webhook] Added ${creditsToAdd} credits to user ${userId}`);
        } catch (error) {
            console.error("[Stripe Webhook] DB update failed:", error);
            return NextResponse.json({ message: "DB update failed" }, { status: 500 });
        }
    }

    return NextResponse.json({ received: true });
}
