import { auth } from "@clerk/nextjs/server";
import { NextResponse } from "next/server";
import prisma from "@/lib/prisma";
import { stripe } from "@/lib/stripe";

// GET /api/billing - Get user's billing info and invoices
export async function GET() {
    try {
        const { userId } = await auth();
        if (!userId) return NextResponse.json({ message: "Unauthorized" }, { status: 401 });

        const user = await prisma.user.findUnique({ where: { clerkId: userId } });
        if (!user) return NextResponse.json({ message: "User not found" }, { status: 404 });

        const transactions = await prisma.creditTransaction.findMany({
            where: { userId: user.id },
            orderBy: { createdAt: "desc" },
            take: 10,
        });

        return NextResponse.json({ credits: user.credits, plan: user.plan, transactions });
    } catch (error) {
        console.error("[GET /api/billing]", error);
        return NextResponse.json({ message: "Internal server error" }, { status: 500 });
    }
}

// POST /api/billing - Create a Stripe Checkout session
export async function POST(req: Request) {
    try {
        const { userId } = await auth();
        if (!userId) return NextResponse.json({ message: "Unauthorized" }, { status: 401 });

        const { planKey } = await req.json();
        const user = await prisma.user.findUnique({ where: { clerkId: userId } });
        if (!user) return NextResponse.json({ message: "User not found" }, { status: 404 });

        const { PLANS } = await import("@/lib/stripe");
        const plan = PLANS[planKey as keyof typeof PLANS];
        if (!plan) return NextResponse.json({ message: "Invalid plan" }, { status: 400 });

        const appUrl = process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000";

        const session = await stripe.checkout.sessions.create({
            mode: "payment",
            payment_method_types: ["card"],
            customer_email: user.email,
            metadata: {
                userId: user.id,
                planKey,
                credits: plan.credits.toString(),
            },
            line_items: [
                {
                    quantity: 1,
                    price_data: {
                        currency: "usd",
                        unit_amount: plan.price * 100,
                        product_data: {
                            name: `Demo Arcade ${plan.name} Pack`,
                            description: `${plan.credits} AI video credits`,
                        },
                    },
                },
            ],
            success_url: `${appUrl}/dashboard/billing?success=true&session_id={CHECKOUT_SESSION_ID}`,
            cancel_url: `${appUrl}/dashboard/billing?canceled=true`,
        });

        return NextResponse.json({ url: session.url });
    } catch (error: any) {
        console.error("[POST /api/billing]", error);
        return NextResponse.json({ message: error.message || "Internal server error" }, { status: 500 });
    }
}
