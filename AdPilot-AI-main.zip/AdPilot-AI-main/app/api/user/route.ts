import { auth, currentUser } from "@clerk/nextjs/server";
import { NextResponse } from "next/server";
import prisma from "@/lib/prisma";

// GET /api/user - Fetch or create user, return credits and profile
export async function GET() {
    try {
        const { userId } = await auth();
        if (!userId) {
            return NextResponse.json({ message: "Unauthorized" }, { status: 401 });
        }

        // Find or create user in DB
        let user = await prisma.user.findUnique({
            where: { clerkId: userId },
        });

        if (!user) {
            const clerkUser = await currentUser();
            if (!clerkUser) {
                return NextResponse.json({ message: "User not found" }, { status: 404 });
            }

            user = await prisma.user.create({
                data: {
                    clerkId: userId,
                    email: clerkUser.emailAddresses[0]?.emailAddress || "",
                    name: `${clerkUser.firstName || ""} ${clerkUser.lastName || ""}`.trim(),
                    imageUrl: clerkUser.imageUrl,
                    credits: 3, // 3 free credits on signup
                },
            });
        }

        return NextResponse.json({
            id: user.id,
            credits: user.credits,
            plan: user.plan,
            email: user.email,
            name: user.name,
        });
    } catch (error) {
        console.error("[GET /api/user]", error);
        return NextResponse.json({ message: "Internal server error" }, { status: 500 });
    }
}
