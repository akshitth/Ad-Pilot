import { auth } from "@clerk/nextjs/server";
import { NextRequest, NextResponse } from "next/server";
import OpenAI from "openai";

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export async function POST(req: NextRequest) {
    try {
        const { userId } = await auth();
        if (!userId) {
            return NextResponse.json({ message: "Unauthorized" }, { status: 401 });
        }

        const { product, tone } = await req.json();
        if (!product) {
            return NextResponse.json({ message: "Product description required" }, { status: 400 });
        }

        const completion = await openai.chat.completions.create({
            model: "gpt-4o-mini",
            messages: [
                {
                    role: "system",
                    content: `You are a world-class UGC (User Generated Content) video ad copywriter. 
          Write a natural, conversational ad script for a person speaking directly to camera.
          The tone should be ${tone || "professional"}.
          Keep it under 60 seconds (about 150 words).
          Start with a hook, present the problem, offer the solution, and end with a CTA.
          Do NOT include instructions like [PAUSE] or [SMILE]. Write only what should be spoken.`,
                },
                {
                    role: "user",
                    content: `Write a UGC video ad script for: ${product}`,
                },
            ],
            max_tokens: 300,
            temperature: 0.7,
        });

        const script = completion.choices[0]?.message?.content?.trim();
        return NextResponse.json({ script });
    } catch (error: any) {
        console.error("[POST /api/generate-script]", error);
        return NextResponse.json({ message: error.message || "Failed to generate script" }, { status: 500 });
    }
}
