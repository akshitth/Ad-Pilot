import { auth } from "@clerk/nextjs/server";
import { NextResponse } from "next/server";
import prisma from "@/lib/prisma";

// GET /api/videos - Fetch user's videos
export async function GET() {
    try {
        const { userId } = await auth();
        if (!userId) return NextResponse.json({ message: "Unauthorized" }, { status: 401 });

        const user = await prisma.user.findUnique({ where: { clerkId: userId } });
        if (!user) return NextResponse.json({ message: "User not found" }, { status: 404 });

        const videos = await prisma.video.findMany({
            where: { userId: user.id },
            orderBy: { createdAt: "desc" },
        });

        return NextResponse.json({ videos });
    } catch (error) {
        console.error("[GET /api/videos]", error);
        return NextResponse.json({ message: "Internal server error" }, { status: 500 });
    }
}
