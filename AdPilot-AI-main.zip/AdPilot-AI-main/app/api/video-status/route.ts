import { auth } from "@clerk/nextjs/server";
import { NextRequest, NextResponse } from "next/server";
import prisma from "@/lib/prisma";

// GET /api/video-status?jobId=xxx
// Polls HeyGen for video completion status
export async function GET(req: NextRequest) {
    try {
        const { userId } = await auth();
        if (!userId) {
            return NextResponse.json({ message: "Unauthorized" }, { status: 401 });
        }

        const jobId = req.nextUrl.searchParams.get("jobId");
        if (!jobId) {
            return NextResponse.json({ message: "Missing jobId" }, { status: 400 });
        }

        // Check HeyGen status
        const heygenRes = await fetch(`https://api.heygen.com/v1/video_status.get?video_id=${jobId}`, {
            headers: { "X-Api-Key": process.env.HEYGEN_API_KEY! },
        });

        if (!heygenRes.ok) {
            return NextResponse.json({ status: "PROCESSING" });
        }

        const heygenData = await heygenRes.json();
        const heygenStatus = heygenData?.data?.status;
        const videoUrl = heygenData?.data?.video_url;
        const thumbnailUrl = heygenData?.data?.thumbnail_url;

        if (heygenStatus === "completed" && videoUrl) {
            // Update the video record in DB
            const user = await prisma.user.findUnique({ where: { clerkId: userId } });
            if (user) {
                await prisma.video.updateMany({
                    where: { externalJobId: jobId, userId: user.id },
                    data: {
                        status: "COMPLETED",
                        videoUrl,
                        thumbnailUrl,
                    },
                });
            }

            return NextResponse.json({ status: "COMPLETED", videoUrl, thumbnailUrl });
        }

        if (heygenStatus === "failed") {
            const user = await prisma.user.findUnique({ where: { clerkId: userId } });
            if (user) {
                await prisma.video.updateMany({
                    where: { externalJobId: jobId, userId: user.id },
                    data: { status: "FAILED", errorMessage: "HeyGen rendering failed" },
                });
                // Refund 1 credit
                await prisma.user.update({
                    where: { id: user.id },
                    data: { credits: { increment: 1 } },
                });
            }
            return NextResponse.json({ status: "FAILED", error: "Video rendering failed" });
        }

        return NextResponse.json({ status: "PROCESSING" });
    } catch (error: any) {
        console.error("[GET /api/video-status]", error);
        return NextResponse.json({ status: "PROCESSING" });
    }
}
