import { auth } from "@clerk/nextjs/server";
import { NextRequest, NextResponse } from "next/server";
import prisma from "@/lib/prisma";
import { supabaseAdmin } from "@/lib/supabase";
import { VOICE_TONES } from "@/lib/actors";
import { v4 as uuidv4 } from "uuid";

export async function POST(req: NextRequest) {
    try {
        const { userId } = await auth();
        if (!userId) {
            return NextResponse.json({ message: "Unauthorized" }, { status: 401 });
        }

        const { actorId, actorName, script, voiceTone } = await req.json();

        if (!actorId || !actorName || !script?.trim()) {
            return NextResponse.json({ message: "Missing required fields" }, { status: 400 });
        }

        // 1. Check user credits
        const user = await prisma.user.findUnique({ where: { clerkId: userId } });
        if (!user) {
            return NextResponse.json({ message: "User not found" }, { status: 404 });
        }
        if (user.credits < 1) {
            return NextResponse.json(
                { message: "Insufficient credits. Please purchase more." },
                { status: 403 }
            );
        }

        // 2. Find the voice ID from VOICE_TONES
        const voiceConfig = VOICE_TONES.find((t) => t.value === voiceTone) || VOICE_TONES[0];

        // 3. ElevenLabs TTS: Convert script to audio
        const ttsResponse = await fetch(
            `https://api.elevenlabs.io/v1/text-to-speech/${voiceConfig.elevenLabsId}`,
            {
                method: "POST",
                headers: {
                    "xi-api-key": process.env.ELEVENLABS_API_KEY!,
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({
                    text: script,
                    model_id: "eleven_multilingual_v2",
                    voice_settings: { stability: 0.5, similarity_boost: 0.75 },
                }),
            }
        );

        if (!ttsResponse.ok) {
            const errText = await ttsResponse.text();
            throw new Error(`ElevenLabs TTS failed: ${errText}`);
        }

        const audioBuffer = await ttsResponse.arrayBuffer();
        const audioFileName = `audio/${user.id}/${uuidv4()}.mp3`;

        // 4. Upload audio to Supabase Storage
        const { error: uploadError } = await supabaseAdmin.storage
            .from("ugc-genie-media")
            .upload(audioFileName, Buffer.from(audioBuffer), {
                contentType: "audio/mpeg",
                upsert: false,
            });

        if (uploadError) throw new Error(`Supabase upload failed: ${uploadError.message}`);

        const { data: publicUrlData } = supabaseAdmin.storage
            .from("ugc-genie-media")
            .getPublicUrl(audioFileName);

        const audioUrl = publicUrlData.publicUrl;

        // 5. Create Video record in DB (PROCESSING state)
        const video = await prisma.video.create({
            data: {
                userId: user.id,
                title: `Ad for ${actorName} - ${new Date().toLocaleDateString()}`,
                script,
                actorId,
                actorName,
                voiceTone,
                audioUrl,
                status: "PROCESSING",
            },
        });

        // 6. Start HeyGen Video generation
        const heygenResponse = await fetch("https://api.heygen.com/v2/video/generate", {
            method: "POST",
            headers: {
                "X-Api-Key": process.env.HEYGEN_API_KEY!,
                "Content-Type": "application/json",
            },
            body: JSON.stringify({
                video_inputs: [
                    {
                        character: {
                            type: "avatar",
                            avatar_id: actorId,
                            avatar_style: "normal",
                        },
                        voice: {
                            type: "audio",
                            audio_url: audioUrl,
                        },
                    },
                ],
                dimension: { width: 1080, height: 1920 },
                aspect_ratio: "9:16",
            }),
        });

        if (!heygenResponse.ok) {
            // Update video to FAILED and refund credit
            await prisma.video.update({
                where: { id: video.id },
                data: { status: "FAILED", errorMessage: "HeyGen API error" },
            });
            const errText = await heygenResponse.text();
            throw new Error(`HeyGen API failed: ${errText}`);
        }

        const heygenData = await heygenResponse.json();
        const externalJobId = heygenData?.data?.video_id;

        // 7. Update video with HeyGen job ID and deduct 1 credit
        await Promise.all([
            prisma.video.update({
                where: { id: video.id },
                data: { externalJobId },
            }),
            prisma.user.update({
                where: { id: user.id },
                data: { credits: { decrement: 1 } },
            }),
            prisma.creditTransaction.create({
                data: {
                    userId: user.id,
                    amount: -1,
                    type: "USAGE",
                    description: `Video generation: ${video.title}`,
                },
            }),
        ]);

        return NextResponse.json({
            jobId: externalJobId,
            videoId: video.id,
            message: "Video generation started. Polling for completion...",
        });
    } catch (error: any) {
        console.error("[POST /api/generate]", error);
        return NextResponse.json(
            { message: error.message || "Internal server error" },
            { status: 500 }
        );
    }
}
