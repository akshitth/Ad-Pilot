import type { Metadata } from "next";
import { Inter } from "next/font/google";
import { ClerkProvider } from "@clerk/nextjs";
import { Providers } from "@/components/providers";
import "./globals.css";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "Demo Arcade | AI Video Ad Generator",
  description:
    "Create realistic AI-powered UGC video ads in minutes. Choose an actor, write your script, and generate a professional lip-synced video ad instantly.",
  keywords: "AI video ads, UGC ads, AI actors, lip-sync video, video marketing",
  openGraph: {
    title: "Demo Arcade | AI Video Ad Generator",
    description: "Create realistic AI-powered video ads in minutes.",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <ClerkProvider>
      <html lang="en" className="dark">
        <body className={inter.className}>
          <Providers>{children}</Providers>
        </body>
      </html>
    </ClerkProvider>
  );
}
