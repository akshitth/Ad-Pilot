import "dotenv/config";
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

async function test() {
    try {
        const count = await prisma.user.count();
        console.log("✅ DB connected! Users:", count);
        const videos = await prisma.video.count();
        console.log("✅ Videos:", videos);
    } catch (e: any) {
        console.error("❌ Error:", e.message);
    } finally {
        await prisma.$disconnect();
    }
}

test();
