"use client";

import { motion } from "framer-motion";
import { Check } from "lucide-react";
import { cn } from "@/lib/utils";
import { AI_ACTORS, type Actor } from "@/lib/actors";

interface ActorGridProps {
    selectedActorId: string | null;
    onSelect: (actor: Actor) => void;
}

export function ActorGrid({ selectedActorId, onSelect }: ActorGridProps) {
    return (
        <div className="grid grid-cols-2 gap-3">
            {AI_ACTORS.map((actor, i) => {
                const isSelected = selectedActorId === actor.id;
                return (
                    <motion.button
                        key={actor.id}
                        initial={{ opacity: 0, y: 16 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: i * 0.06, duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
                        onClick={() => onSelect(actor)}
                        whileHover={{ scale: 1.03, transition: { duration: 0.2 } }}
                        whileTap={{ scale: 0.98 }}
                        className={cn(
                            "relative rounded-xl overflow-hidden text-left group transition-all",
                            isSelected
                                ? "ring-2 ring-violet-500 ring-offset-2 ring-offset-transparent"
                                : "hover:ring-1 hover:ring-white/20"
                        )}
                        style={{
                            border: isSelected ? "1px solid rgba(139,92,246,0.5)" : "1px solid rgba(255,255,255,0.07)",
                        }}
                    >
                        {/* Actor image */}
                        <div className="aspect-[3/4] relative overflow-hidden">
                            <img
                                src={actor.imageUrl}
                                alt={actor.name}
                                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                            />

                            {/* Gradient overlay */}
                            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />

                            {/* Selected glow overlay */}
                            {isSelected && (
                                <motion.div
                                    initial={{ opacity: 0 }} animate={{ opacity: 1 }}
                                    className="absolute inset-0"
                                    style={{ background: "linear-gradient(135deg, rgba(139,92,246,0.15), transparent)" }}
                                />
                            )}
                        </div>

                        {/* Info */}
                        <div className="absolute bottom-0 left-0 right-0 p-3">
                            <p className="text-sm font-semibold text-white leading-tight">{actor.name}</p>
                            <p className="text-xs text-white/50 mt-0.5">{actor.description}</p>
                        </div>

                        {/* Selected check */}
                        <AnimatedCheck show={isSelected} />
                    </motion.button>
                );
            })}
        </div>
    );
}

function AnimatedCheck({ show }: { show: boolean }) {
    return (
        <motion.div
            initial={{ scale: 0, opacity: 0 }}
            animate={show ? { scale: 1, opacity: 1 } : { scale: 0, opacity: 0 }}
            transition={{ type: "spring", stiffness: 500, damping: 30 }}
            className="absolute top-2.5 right-2.5 w-6 h-6 rounded-full flex items-center justify-center"
            style={{ background: "linear-gradient(135deg, #8b5cf6, #6366f1)" }}
        >
            <Check className="w-3.5 h-3.5 text-white" strokeWidth={3} />
        </motion.div>
    );
}
