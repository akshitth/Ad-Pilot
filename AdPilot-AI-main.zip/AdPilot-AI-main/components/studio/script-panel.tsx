"use client";

import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Wand2, Sparkles, Loader2, ChevronDown } from "lucide-react";
import { cn } from "@/lib/utils";
import { VOICE_TONES, type Actor } from "@/lib/actors";

interface ScriptPanelProps {
    script: string;
    onScriptChange: (v: string) => void;
    voiceTone: string;
    onVoiceToneChange: (v: string) => void;
    selectedActor: Actor | null;
    onGenerate: () => void;
    isLoading: boolean;
}

export function ScriptPanel({
    script, onScriptChange, voiceTone, onVoiceToneChange,
    selectedActor, onGenerate, isLoading,
}: ScriptPanelProps) {
    const [isGeneratingScript, setIsGeneratingScript] = useState(false);
    const [isFocused, setIsFocused] = useState(false);
    const textareaRef = useRef<HTMLTextAreaElement>(null);

    // Auto-expand textarea
    useEffect(() => {
        const el = textareaRef.current;
        if (!el) return;
        el.style.height = "auto";
        el.style.height = `${Math.max(160, el.scrollHeight)}px`;
    }, [script]);

    const handleGenerateScript = async () => {
        const product = prompt("Describe your product or service:");
        if (!product) return;
        setIsGeneratingScript(true);
        try {
            const res = await fetch("/api/generate-script", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ product, tone: voiceTone }),
            });
            const data = await res.json();
            if (data.script) onScriptChange(data.script);
        } catch (e) { console.error(e); }
        finally { setIsGeneratingScript(false); }
    };

    const wordCount = script.trim().split(/\s+/).filter(Boolean).length;
    const canGenerate = !!selectedActor && script.trim().length > 10 && !isLoading;

    return (
        <div className="space-y-5">
            {/* Actor badge */}
            <AnimatePresence mode="wait">
                {selectedActor ? (
                    <motion.div key="actor"
                        initial={{ opacity: 0, y: -8, scale: 0.96 }}
                        animate={{ opacity: 1, y: 0, scale: 1 }}
                        exit={{ opacity: 0, y: -8, scale: 0.96 }}
                        transition={{ duration: 0.25, ease: [0.22, 1, 0.36, 1] }}
                        className="flex items-center gap-3 rounded-xl p-3 relative overflow-hidden"
                        style={{
                            background: "rgba(139,92,246,0.08)",
                            border: "1px solid rgba(139,92,246,0.2)",
                        }}>
                        <img src={selectedActor.imageUrl} alt={selectedActor.name}
                            className="w-10 h-10 rounded-lg object-cover" />
                        <div>
                            <p className="text-sm font-semibold text-white">{selectedActor.name}</p>
                            <p className="text-xs text-white/40">{selectedActor.description}</p>
                        </div>
                        <div className="ml-auto flex gap-1.5">
                            {selectedActor.languages.slice(0, 3).map((l) => (
                                <span key={l} className="text-[10px] font-medium px-2 py-0.5 rounded"
                                    style={{ background: "rgba(139,92,246,0.15)", color: "rgba(167,139,250,0.9)", border: "1px solid rgba(139,92,246,0.2)" }}>
                                    {l}
                                </span>
                            ))}
                        </div>
                    </motion.div>
                ) : (
                    <motion.div key="empty"
                        initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                        className="rounded-xl p-3 text-sm text-white/25 border border-dashed border-white/10">
                        ← Select an actor to get started
                    </motion.div>
                )}
            </AnimatePresence>

            {/* Voice Tone */}
            <div>
                <label className="text-[11px] font-bold text-white/30 uppercase tracking-widest block mb-2.5">
                    Voice Tone
                </label>
                <div className="flex flex-wrap gap-2">
                    {VOICE_TONES.map((tone) => (
                        <motion.button
                            key={tone.value}
                            whileHover={{ scale: 1.04 }} whileTap={{ scale: 0.97 }}
                            onClick={() => onVoiceToneChange(tone.value)}
                            className={cn(
                                "text-xs font-medium px-3 py-1.5 rounded-lg transition-all",
                                voiceTone === tone.value
                                    ? "text-violet-300"
                                    : "text-white/35 hover:text-white/60"
                            )}
                            style={voiceTone === tone.value ? {
                                background: "rgba(139,92,246,0.15)",
                                border: "1px solid rgba(139,92,246,0.3)",
                            } : {
                                background: "rgba(255,255,255,0.03)",
                                border: "1px solid rgba(255,255,255,0.07)",
                            }}
                        >
                            {tone.label}
                        </motion.button>
                    ))}
                </div>
            </div>

            {/* Script Textarea */}
            <div>
                <div className="flex items-center justify-between mb-2.5">
                    <label className="text-[11px] font-bold text-white/30 uppercase tracking-widest">Your Script</label>
                    <motion.button
                        onClick={handleGenerateScript}
                        disabled={isGeneratingScript}
                        whileHover={{ scale: 1.04 }} whileTap={{ scale: 0.97 }}
                        className="flex items-center gap-1.5 text-xs font-medium text-violet-400 hover:text-violet-300 transition-colors disabled:opacity-50"
                    >
                        {isGeneratingScript
                            ? <><Loader2 className="w-3.5 h-3.5 animate-spin" />Generating...</>
                            : <><Wand2 className="w-3.5 h-3.5" />AI Write Script</>
                        }
                    </motion.button>
                </div>

                <motion.div
                    animate={isFocused ? {
                        boxShadow: "0 0 0 1px rgba(139,92,246,0.3), 0 0 20px rgba(139,92,246,0.1)"
                    } : {
                        boxShadow: "none"
                    }}
                    transition={{ duration: 0.2 }}
                    className="rounded-xl overflow-hidden"
                    style={{ border: `1px solid ${isFocused ? "rgba(139,92,246,0.35)" : "rgba(255,255,255,0.08)"}` }}
                >
                    <textarea
                        ref={textareaRef}
                        value={script}
                        onChange={(e) => onScriptChange(e.target.value)}
                        onFocus={() => setIsFocused(true)}
                        onBlur={() => setIsFocused(false)}
                        placeholder={"Hi, I'm [Actor Name], and I want to tell you about something that changed my life..."}
                        className="w-full px-4 py-3.5 text-sm text-white/85 placeholder:text-white/20 resize-none focus:outline-none leading-relaxed"
                        style={{ background: "rgba(255,255,255,0.03)", minHeight: "160px" }}
                        maxLength={1000}
                    />
                </motion.div>

                <div className="flex justify-between mt-2 px-1">
                    <p className="text-[11px] text-white/25">{wordCount} words · ~{Math.ceil(wordCount / 130)} min video</p>
                    <p className="text-[11px] text-white/25">{script.length} / 1000</p>
                </div>
            </div>

            {/* Generate Button */}
            <motion.button
                onClick={onGenerate}
                disabled={!canGenerate}
                whileHover={canGenerate ? { scale: 1.02 } : {}}
                whileTap={canGenerate ? { scale: 0.98 } : {}}
                animate={canGenerate ? { opacity: 1 } : { opacity: 0.4 }}
                className="w-full flex items-center justify-center gap-2.5 py-4 rounded-xl font-bold text-base text-white relative overflow-hidden disabled:cursor-not-allowed"
                style={canGenerate ? {
                    background: "linear-gradient(135deg, #8b5cf6, #6366f1, #22d3ee)",
                    backgroundSize: "200% 200%",
                    boxShadow: "0 4px 20px rgba(139,92,246,0.4), 0 0 60px rgba(139,92,246,0.1)",
                } : {
                    background: "rgba(255,255,255,0.06)",
                    border: "1px solid rgba(255,255,255,0.08)",
                }}
            >
                {/* Shimmer on hover */}
                {canGenerate && (
                    <motion.div
                        className="absolute inset-0"
                        style={{ background: "linear-gradient(90deg, transparent, rgba(255,255,255,0.1), transparent)" }}
                        animate={{ x: ["-100%", "200%"] }}
                        transition={{ duration: 2, repeat: Infinity, ease: "linear", repeatDelay: 1 }}
                    />
                )}
                <span className="relative z-10 flex items-center gap-2.5">
                    {isLoading ? (
                        <><Loader2 className="w-5 h-5 animate-spin" />Generating Video...</>
                    ) : (
                        <><Sparkles className="w-5 h-5" />Generate Video <span className="text-white/50 font-normal text-sm">(1 credit)</span></>
                    )}
                </span>
            </motion.button>

            {!selectedActor && (
                <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }}
                    className="text-xs text-center text-white/25">
                    Select an actor on the left to enable generation
                </motion.p>
            )}
        </div>
    );
}
