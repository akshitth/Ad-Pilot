"use client";

import { motion, AnimatePresence } from "framer-motion";
import { Download, Loader2, AlertCircle, Video } from "lucide-react";
import { useQuery } from "@tanstack/react-query";

interface VideoPreviewProps {
    isLoading: boolean;
    videoUrl?: string;
    error: Error | null;
    jobId?: string;
}

export function VideoPreview({ isLoading, videoUrl, error, jobId }: VideoPreviewProps) {
    const { data: pollData } = useQuery({
        queryKey: ["video-status", jobId],
        queryFn: async () => {
            const res = await fetch(`/api/video-status?jobId=${jobId}`);
            if (!res.ok) throw new Error("Status check failed");
            return res.json();
        },
        enabled: !!jobId && !videoUrl,
        refetchInterval: 5000,
        refetchIntervalInBackground: false,
    });

    const finalVideoUrl = videoUrl || pollData?.videoUrl;
    const isProcessing = isLoading || (!!jobId && !finalVideoUrl);

    return (
        <div>
            <h2 className="text-[11px] font-bold text-white/30 uppercase tracking-widest mb-3">
                Video Preview
            </h2>

            <div className="relative rounded-xl overflow-hidden aspect-video"
                style={{ background: "rgba(255,255,255,0.025)", border: "1px solid rgba(255,255,255,0.07)" }}>

                {/* Grid bg inside */}
                <div className="absolute inset-0 dot-bg opacity-50 pointer-events-none" />

                <AnimatePresence mode="wait">

                    {/* Idle */}
                    {!isProcessing && !finalVideoUrl && !error && (
                        <motion.div key="idle"
                            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                            className="absolute inset-0 flex flex-col items-center justify-center gap-3">
                            <motion.div
                                animate={{ opacity: [0.2, 0.5, 0.2] }}
                                transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
                                className="w-14 h-14 rounded-2xl flex items-center justify-center"
                                style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)" }}>
                                <Video className="w-6 h-6 text-white/20" />
                            </motion.div>
                            <p className="text-sm text-white/25">Your video will appear here</p>
                        </motion.div>
                    )}

                    {/* Processing */}
                    {isProcessing && (
                        <motion.div key="processing"
                            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                            className="absolute inset-0 flex flex-col items-center justify-center gap-5">
                            {/* Rings */}
                            <div className="relative w-20 h-20 flex items-center justify-center">
                                <motion.div
                                    className="absolute inset-0 rounded-full border border-violet-500/30"
                                    animate={{ scale: [1, 1.6], opacity: [0.5, 0] }}
                                    transition={{ duration: 1.8, repeat: Infinity, ease: "easeOut" }}
                                />
                                <motion.div
                                    className="absolute inset-0 rounded-full border border-violet-500/20"
                                    animate={{ scale: [1, 1.9], opacity: [0.4, 0] }}
                                    transition={{ duration: 1.8, repeat: Infinity, ease: "easeOut", delay: 0.4 }}
                                />
                                <div className="relative w-12 h-12 rounded-full flex items-center justify-center"
                                    style={{ background: "rgba(139,92,246,0.12)", border: "1px solid rgba(139,92,246,0.3)" }}>
                                    <Loader2 className="w-6 h-6 text-violet-400 animate-spin" />
                                </div>
                            </div>

                            {/* Progress shimmer bar */}
                            <div className="w-40 h-1 rounded-full overflow-hidden"
                                style={{ background: "rgba(255,255,255,0.06)" }}>
                                <motion.div
                                    className="h-full rounded-full"
                                    style={{ background: "linear-gradient(90deg, #8b5cf6, #22d3ee)" }}
                                    animate={{ x: ["-100%", "200%"] }}
                                    transition={{ duration: 1.5, repeat: Infinity, ease: "linear" }}
                                />
                            </div>

                            <div className="text-center">
                                <p className="text-sm font-semibold text-white/70">Generating your video...</p>
                                <p className="text-xs text-white/30 mt-1">
                                    {isLoading ? "Starting AI pipeline..." : "Rendering lip-sync (2 – 5 min)"}
                                </p>
                            </div>
                        </motion.div>
                    )}

                    {/* Video ready */}
                    {finalVideoUrl && !isProcessing && (
                        <motion.div key="video"
                            initial={{ opacity: 0, scale: 0.96 }} animate={{ opacity: 1, scale: 1 }}
                            transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
                            className="absolute inset-0">
                            <video src={finalVideoUrl} controls className="w-full h-full object-cover" />
                        </motion.div>
                    )}

                    {/* Error */}
                    {error && (
                        <motion.div key="error"
                            initial={{ opacity: 0 }} animate={{ opacity: 1 }}
                            className="absolute inset-0 flex flex-col items-center justify-center gap-3 p-4 text-center">
                            <div className="w-12 h-12 rounded-2xl flex items-center justify-center"
                                style={{ background: "rgba(239,68,68,0.1)", border: "1px solid rgba(239,68,68,0.2)" }}>
                                <AlertCircle className="w-6 h-6 text-red-400" />
                            </div>
                            <p className="text-sm font-semibold text-red-400">Generation Failed</p>
                            <p className="text-xs text-white/30 max-w-[240px]">{error.message}</p>
                        </motion.div>
                    )}
                </AnimatePresence>
            </div>

            {/* Download */}
            <AnimatePresence>
                {finalVideoUrl && (
                    <motion.a
                        href={finalVideoUrl} download
                        initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.2 }}
                        whileHover={{ scale: 1.02 }}
                        className="flex items-center justify-center gap-2 w-full mt-3 py-2.5 rounded-xl text-sm font-medium text-white/60 hover:text-white transition-colors"
                        style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)" }}
                    >
                        <Download className="w-4 h-4" />
                        Download MP4
                    </motion.a>
                )}
            </AnimatePresence>
        </div>
    );
}
