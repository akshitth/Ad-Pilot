"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import { SignedIn, SignedOut, UserButton } from "@clerk/nextjs";
import { Sparkles } from "lucide-react";

export function Navbar() {
    const [scrolled, setScrolled] = useState(false);
    useEffect(() => {
        const h = () => setScrolled(window.scrollY > 20);
        window.addEventListener("scroll", h, { passive: true });
        return () => window.removeEventListener("scroll", h);
    }, []);

    return (
        <motion.nav
            initial={{ y: -20, opacity: 0 }} animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
            className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${scrolled ? "glass border-b border-white/5 shadow-glass" : "bg-transparent"}`}
        >
            <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
                {/* Logo */}
                <Link href="/" className="flex items-center gap-2.5 group">
                    <motion.div
                        whileHover={{ scale: 1.1, rotate: 5 }}
                        className="w-8 h-8 rounded-xl flex items-center justify-center"
                        style={{ background: "linear-gradient(135deg, #8b5cf6, #6366f1)" }}>
                        <Sparkles className="w-4 h-4 text-white" />
                    </motion.div>
                    <span className="font-black text-lg text-white tracking-tight">
                        Demo<span className="gradient-text">-Arcade</span>
                    </span>
                </Link>

                {/* Nav links */}
                <div className="hidden md:flex items-center gap-8">
                    {[["Features", "/#features"], ["How it Works", "/#how-it-works"], ["Pricing", "/pricing"]].map(([label, href]) => (
                        <Link key={label} href={href}
                            className="relative text-sm font-medium text-white/50 hover:text-white transition-colors group py-1">
                            {label}
                            <span className="absolute bottom-0 left-0 w-0 h-px bg-violet-400 group-hover:w-full transition-all duration-300" />
                        </Link>
                    ))}
                </div>

                {/* CTA */}
                <div className="flex items-center gap-3">
                    <SignedOut>
                        <Link href="/sign-in" className="text-sm font-medium text-white/50 hover:text-white transition-colors px-3 py-2">
                            Sign In
                        </Link>
                        <motion.div whileHover={{ scale: 1.04 }} whileTap={{ scale: 0.97 }}>
                            <Link href="/sign-up"
                                className="text-sm font-bold text-white px-4 py-2 rounded-lg"
                                style={{ background: "linear-gradient(135deg, #8b5cf6, #6366f1)" }}>
                                Get Started
                            </Link>
                        </motion.div>
                    </SignedOut>
                    <SignedIn>
                        <motion.div whileHover={{ scale: 1.04 }} whileTap={{ scale: 0.97 }}>
                            <Link href="/dashboard"
                                className="text-sm font-bold text-white px-4 py-2 rounded-lg mr-2"
                                style={{ background: "linear-gradient(135deg, #8b5cf6, #6366f1)" }}>
                                Dashboard
                            </Link>
                        </motion.div>
                        <UserButton afterSignOutUrl="/" />
                    </SignedIn>
                </div>
            </div>
        </motion.nav>
    );
}
