"use client";

import { useEffect, useRef } from "react";

export function AnimatedMeshBackground() {
    const ref = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const el = ref.current;
        if (!el) return;
        let t = 0;
        let raf: number;
        const animate = () => {
            t += 0.004;
            const x1 = 20 + 20 * Math.sin(t * 0.6);
            const y1 = 15 + 15 * Math.cos(t * 0.4);
            const x2 = 75 + 15 * Math.cos(t * 0.5);
            const y2 = 55 + 20 * Math.sin(t * 0.7);
            const x3 = 50 + 25 * Math.sin(t * 0.8);
            const y3 = 85 + 10 * Math.cos(t * 0.6);
            el.style.background = `
        radial-gradient(ellipse at ${x1}% ${y1}%, rgba(167,139,250,0.25) 0%, transparent 55%),
        radial-gradient(ellipse at ${x2}% ${y2}%, rgba(99,102,241,0.2) 0%, transparent 50%),
        radial-gradient(ellipse at ${x3}% ${y3}%, rgba(56,189,248,0.15) 0%, transparent 45%),
        radial-gradient(ellipse at 85% 5%, rgba(244,114,182,0.18) 0%, transparent 40%),
        linear-gradient(155deg, #fefce8 0%, #faf5ff 25%, #eff6ff 50%, #f0fdf4 75%, #fff7ed 100%)
      `;
            raf = requestAnimationFrame(animate);
        };
        animate();
        return () => cancelAnimationFrame(raf);
    }, []);

    return (
        <div ref={ref} className="fixed inset-0 -z-10" style={{ willChange: "background" }} />
    );
}
