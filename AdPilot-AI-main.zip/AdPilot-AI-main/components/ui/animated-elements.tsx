"use client";

import { useEffect, useRef, useState } from "react";

interface TypewriterTextProps {
    words: string[];
    className?: string;
    speed?: number;
    pause?: number;
}

export function TypewriterText({
    words,
    className = "",
    speed = 80,
    pause = 1800,
}: TypewriterTextProps) {
    const [displayed, setDisplayed] = useState("");
    const [wordIdx, setWordIdx] = useState(0);
    const [isDeleting, setIsDeleting] = useState(false);
    const timeoutRef = useRef<ReturnType<typeof setTimeout>>();

    useEffect(() => {
        const currentWord = words[wordIdx];

        const tick = () => {
            if (isDeleting) {
                setDisplayed((prev) => prev.slice(0, -1));
                if (displayed.length <= 1) {
                    setIsDeleting(false);
                    setWordIdx((i) => (i + 1) % words.length);
                    timeoutRef.current = setTimeout(tick, 400);
                    return;
                }
                timeoutRef.current = setTimeout(tick, speed / 2);
            } else {
                setDisplayed(currentWord.slice(0, displayed.length + 1));
                if (displayed.length >= currentWord.length - 1) {
                    timeoutRef.current = setTimeout(() => setIsDeleting(true), pause);
                    return;
                }
                timeoutRef.current = setTimeout(tick, speed);
            }
        };

        timeoutRef.current = setTimeout(tick, speed);
        return () => clearTimeout(timeoutRef.current);
    }, [displayed, isDeleting, wordIdx, words, speed, pause]);

    return (
        <span className={className}>
            {displayed}
            <span className="animate-blink text-purple-400 ml-0.5">|</span>
        </span>
    );
}

interface AnimatedCounterProps {
    target: number;
    suffix?: string;
    prefix?: string;
    duration?: number;
    className?: string;
}

export function AnimatedCounter({
    target,
    suffix = "",
    prefix = "",
    duration = 2000,
    className = "",
}: AnimatedCounterProps) {
    const [count, setCount] = useState(0);
    const ref = useRef<HTMLSpanElement>(null);
    const hasRun = useRef(false);

    useEffect(() => {
        const observer = new IntersectionObserver(
            ([entry]) => {
                if (entry.isIntersecting && !hasRun.current) {
                    hasRun.current = true;
                    const start = Date.now();
                    const tick = () => {
                        const elapsed = Date.now() - start;
                        const progress = Math.min(elapsed / duration, 1);
                        // Ease out
                        const eased = 1 - Math.pow(1 - progress, 3);
                        setCount(Math.round(eased * target));
                        if (progress < 1) requestAnimationFrame(tick);
                    };
                    requestAnimationFrame(tick);
                }
            },
            { threshold: 0.5 }
        );
        if (ref.current) observer.observe(ref.current);
        return () => observer.disconnect();
    }, [target, duration]);

    return (
        <span ref={ref} className={className}>
            {prefix}{count.toLocaleString()}{suffix}
        </span>
    );
}

export function ShimmerText({ children, className = "" }: { children: React.ReactNode; className?: string }) {
    return (
        <span className={`shimmer-text ${className}`}>
            {children}
        </span>
    );
}

export function FloatingBadge({ children, className = "", delay = 0 }: {
    children: React.ReactNode;
    className?: string;
    delay?: number;
}) {
    return (
        <div
            className={`animate-float-badge ${className}`}
            style={{ animationDelay: `${delay}ms` }}
        >
            {children}
        </div>
    );
}
