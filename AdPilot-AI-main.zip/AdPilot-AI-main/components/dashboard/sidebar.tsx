"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { UserButton, useUser } from "@clerk/nextjs";
import { motion, AnimatePresence } from "framer-motion";
import {
    Sparkles, LayoutDashboard, Film, PlusCircle,
    CreditCard, Settings, Zap, ChevronRight, TrendingUp,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useQuery } from "@tanstack/react-query";

const NAV_ITEMS = [
    { href: "/dashboard", icon: LayoutDashboard, label: "Dashboard", color: "#8b5cf6" },
    { href: "/dashboard/create", icon: PlusCircle, label: "Create Video", color: "#22d3ee" },
    { href: "/dashboard/library", icon: Film, label: "Library", color: "#34d399" },
    { href: "/dashboard/billing", icon: CreditCard, label: "Billing", color: "#fb923c" },
    { href: "/dashboard/settings", icon: Settings, label: "Settings", color: "#94a3b8" },
];

export function DashboardSidebar() {
    const pathname = usePathname();
    const { user } = useUser();

    const { data: userData } = useQuery({
        queryKey: ["user-credits"],
        queryFn: async () => {
            const res = await fetch("/api/user");
            if (!res.ok) throw new Error();
            return res.json();
        },
        enabled: !!user,
    });

    const credits = userData?.credits ?? null;

    return (
        <motion.aside
            initial={{ x: -20, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
            className="w-60 shrink-0 flex flex-col h-full"
            style={{
                background: "rgba(17,17,26,0.95)",
                borderRight: "1px solid rgba(255,255,255,0.06)",
                backdropFilter: "blur(24px)",
            }}
        >
            {/* Logo */}
            <div className="px-5 py-5 border-b border-white/5">
                <Link href="/" className="flex items-center gap-2.5 group">
                    <motion.div
                        whileHover={{ scale: 1.1, rotate: 5 }}
                        className="w-8 h-8 rounded-xl flex items-center justify-center shadow-glow-violet"
                        style={{ background: "linear-gradient(135deg, #8b5cf6, #6366f1)" }}>
                        <Sparkles className="w-4 h-4 text-white" />
                    </motion.div>
                    <span className="font-black text-base text-white tracking-tight">
                        Demo<span className="gradient-text">-Arcade</span>
                    </span>
                </Link>
            </div>

            {/* Credits card */}
            <div className="mx-3 mt-4">
                <motion.div
                    initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.15 }}
                    className="rounded-xl p-3.5 relative overflow-hidden"
                    style={{
                        background: "linear-gradient(135deg, rgba(139,92,246,0.12), rgba(99,102,241,0.08))",
                        border: "1px solid rgba(139,92,246,0.2)",
                    }}
                >
                    <div className="absolute top-0 right-0 w-20 h-20 pointer-events-none"
                        style={{ background: "radial-gradient(circle at 100% 0%, rgba(139,92,246,0.2), transparent 70%)" }} />
                    <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2">
                            <div className="w-5 h-5 rounded-md bg-yellow-500/15 flex items-center justify-center">
                                <Zap className="w-3 h-3 text-yellow-400" />
                            </div>
                            <span className="text-xs font-medium text-white/60">Credits</span>
                        </div>
                        <span className="text-xl font-black gradient-text">{credits ?? "—"}</span>
                    </div>
                    {/* Credit dots */}
                    <div className="flex gap-1 mb-2">
                        {Array.from({ length: 5 }).map((_, i) => (
                            <motion.div key={i}
                                initial={{ scaleX: 0 }} animate={{ scaleX: 1 }}
                                transition={{ delay: 0.3 + i * 0.06, ease: [0.22, 1, 0.36, 1] }}
                                className="h-1 rounded-full flex-1 origin-left"
                                style={{ background: i < (credits ?? 0) ? "linear-gradient(90deg, #8b5cf6, #6366f1)" : "rgba(255,255,255,0.08)" }}
                            />
                        ))}
                    </div>
                    <Link href="/dashboard/billing"
                        className="text-[11px] font-medium text-violet-400 hover:text-violet-300 transition-colors flex items-center gap-1">
                        Top up credits <ChevronRight className="w-3 h-3" />
                    </Link>
                </motion.div>
            </div>

            {/* Nav */}
            <nav className="flex-1 px-2 py-4 space-y-0.5">
                <p className="text-[10px] font-bold uppercase tracking-widest text-white/20 px-3 mb-3">Menu</p>
                {NAV_ITEMS.map((item, idx) => {
                    const isActive = pathname === item.href ||
                        (item.href !== "/dashboard" && pathname.startsWith(item.href));
                    return (
                        <Link key={item.href} href={item.href}>
                            <motion.div
                                initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }}
                                transition={{ delay: 0.1 + idx * 0.05 }}
                                whileHover={{ x: 2 }}
                                className={cn(
                                    "relative flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-colors group",
                                    isActive ? "text-white" : "text-white/40 hover:text-white/70"
                                )}
                                style={isActive ? {
                                    background: `${item.color}12`,
                                    border: `1px solid ${item.color}20`,
                                } : {}}
                            >
                                {/* Active indicator */}
                                {isActive && (
                                    <motion.div
                                        layoutId="sidebar-active"
                                        className="absolute left-0 top-1/2 -translate-y-1/2 w-0.5 h-5 rounded-full"
                                        style={{ background: item.color }}
                                        transition={{ type: "spring", stiffness: 400, damping: 35 }}
                                    />
                                )}
                                <div className={cn("w-7 h-7 rounded-lg flex items-center justify-center transition-all",
                                    isActive ? "" : "group-hover:scale-110"
                                )}
                                    style={{ background: isActive ? `${item.color}18` : "transparent" }}>
                                    <item.icon className="w-4 h-4" style={{ color: isActive ? item.color : "currentColor" }} />
                                </div>
                                <span>{item.label}</span>
                                {isActive && (
                                    <motion.div
                                        initial={{ scale: 0 }} animate={{ scale: 1 }}
                                        className="ml-auto w-1.5 h-1.5 rounded-full"
                                        style={{ background: item.color }}
                                    />
                                )}
                            </motion.div>
                        </Link>
                    );
                })}
            </nav>

            {/* User */}
            <div className="p-3 border-t border-white/5">
                <motion.div
                    whileHover={{ backgroundColor: "rgba(255,255,255,0.03)" }}
                    className="flex items-center gap-2.5 p-2.5 rounded-xl cursor-pointer transition-colors">
                    <UserButton afterSignOutUrl="/" />
                    <div className="min-w-0 flex-1">
                        <p className="text-xs font-semibold text-white/70 truncate">
                            {user?.fullName || user?.username || "User"}
                        </p>
                        <p className="text-[10px] text-white/30 truncate">
                            {user?.primaryEmailAddress?.emailAddress}
                        </p>
                    </div>
                    <TrendingUp className="w-3.5 h-3.5 text-white/15 shrink-0" />
                </motion.div>
            </div>
        </motion.aside>
    );
}
